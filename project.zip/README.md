# Новая Жизнь — WebView Edition v11 Casual Premium

Выбранный вариант визуала: Casual Premium.

## Что добавлено

- HTML/CSS/JS WebView вместо Kivy.
- Яркий premium casual визуал.
- Адаптивный интерфейс под разные экраны.
- Анимации: появление карточек, hover/press, shimmer на кнопках, floating avatar/hero, particles на меню.
- Главное меню.
- Игровой экран.
- Прямые действия на странице без тёмных подменю.
- Фоновая музыка.
- Сохранение через localStorage.
- Кладбище прожитых жизней.
- Настройки.
- Достижения и цель бессмертия.
- GitHub Actions сборка APK.

## Сборка APK

GitHub → Actions → Build Android APK → Run workflow → скачать Artifact `NewLife-CasualPremium-debug-apk`.
