
function apply(obj){
  if(!obj)return;
  for(const [k,v] of Object.entries(obj)){
    if(k==="skill"){ game.skills[v[0]]=(game.skills[v[0]]||0)+v[1]; game.mind += Math.floor(v[1]/4); }
    else if(k==="job"){ game.job = DATA.jobs.find(j=>j.id===v) || null; }
    else if(k==="business"){ game.business = DATA.businesses.find(b=>b.id===v) || game.business; game.businessLevel = Math.max(1,game.businessLevel); }
    else if(k==="home"){ game.home = DATA.properties.find(p=>p.id===v) || game.home; }
    else if(k==="rent"){ game.rent = DATA.properties.find(p=>p.id===v) || game.rent; }
    else if(k==="car"){ game.car = DATA.cars.find(c=>c.id===v) || game.car; }
    else if(k==="partner"){ game.partner=choice(["Саша","Алекс","Марина","Оля","Ира","Никита","Максим","Катя"]); game.relationship="В отношениях"; game.love=rand(35,65); }
    else if(k==="child"){ game.children.push({name:choice(["Миша","Аня","Илья","София","Марк","Алиса"]),age:0}); }
    else if(k==="pet"){ game.pets.push(v); }
    else if(typeof game[k]==="number") game[k]+=v;
    else game[k]=v;
  }
  normalize();
}
function normalize(){
  ["health","feeling","happiness","mental","looks"].forEach(k=>game[k]=clamp(game[k]));
  game.energy=clamp(game.energy,0,game.energyMax);
  game.stress=clamp(game.stress);
  ["money","mind","charisma","creativity","discipline","fame","friends","acquaintances","parents","love","career","jobExp","debt","shares","crypto"].forEach(k=>game[k]=Math.round(game[k]||0));
}
function can(action){
  if(game.energy < (action.cost||0)) return false;
  if(game.money < (action.money||0)) return false;
  const n=action.need||{};
  if(n.age && game.age<n.age)return false;
  if(n.relationship && game.relationship!==n.relationship)return false;
  if(n.education && game.education!==n.education)return false;
  if(n.skill && (game.skills[n.skill]||0)<(n.value||0))return false;
  if(n.mind && game.mind<n.mind)return false;
  if(n.charisma && game.charisma<n.charisma)return false;
  return true;
}
function doAction(action){
  if(!can(action)){toast("Не хватает энергии, денег или условий");return}
  game.energy -= action.cost||0;
  game.money -= action.money||0;
  apply(action.effects);
  log(action.title, action.result);
  currentEvent = currentEvent || generateEvent();
  checkDeath();
  saveGame();
  renderGame();
}
function setupPick(id){
  const a=DATA.setup.find(x=>x.id===id); if(!a)return;
  const spent=Object.entries(game.setupPicks).reduce((s,[id,c])=>s+(DATA.setup.find(x=>x.id===id)?.cost||0)*c,0);
  if(spent+a.cost>15){toast("Не хватает очков детства");return}
  game.setupPicks[id]=(game.setupPicks[id]||0)+1;
  apply(a.effects);
  game.energy = 15 - (spent+a.cost);
  saveGame(); renderSetup();
}
function finishSetup(){
  const spent=Object.values(game.setupPicks).reduce((a,b)=>a+b,0);
  if(spent<=0){toast("Выбери хотя бы одно занятие");return}
  game.setup=false; game.age=16; game.month=0; game.energyMax=100; game.energy=100;
  game.money=rand(3000,30000); game.education="Школа"; game.school=40;
  game.health=clamp(game.health+20); game.feeling=clamp(game.feeling+40); game.happiness=clamp(game.happiness+40); game.mental=clamp(game.mental+20);
  log("Первые 16 лет", "Детство прошло. Твои выборы сформировали стартовые характеристики.");
  currentEvent=generateEvent(); saveGame();
  showModal("Тебе 16 лет", `Стартовые характеристики:\nЗдоровье: ${game.health}\nЧувство жизни: ${game.feeling}\nУм: ${game.mind}\nХаризма: ${game.charisma}\nТворчество: ${game.creativity}\nДисциплина: ${game.discipline}\nДрузья: ${game.friends}`, [{t:"Начать",c:"blue",fn:()=>{closeModal();renderGame();}}]);
}
function nextMonth(){
  if(game.setup)return;
  const notes=[];
  game.month++; if(game.month>=12){game.month=0;game.age++; game.children.forEach(c=>c.age++); notes.push(`Наступил новый год жизни. Тебе ${game.age}.`);}
  game.energy=100;
  if(game.job){
    const income = game.job.id==="blogger" ? Math.max(0, game.fame*rand(300,900)+game.skills["Блогинг"]*600+rand(-15000,45000)) : Math.round(game.job.salary*(1+game.career/150+game.mind/2500));
    game.money+=income; game.energy-=game.job.energy; game.jobExp+=4; game.career+=rand(1,4); game.stress+=Math.floor(game.job.energy/4);
    notes.push(`Работа «${game.job.name}»: +${money(income)}, энергия -${game.job.energy}.`);
  }
  if(game.business){
    const income = game.business.profit*game.businessLevel + game.businessRep*700;
    const roll = rand(1,100);
    if(roll<18){const loss=Math.round(income*.5);game.money-=loss;notes.push(`Бизнес: неудачный месяц, убыток ${money(loss)}.`)}
    else {game.money+=income;notes.push(`Бизнес: прибыль ${money(income)}.`)}
    game.energy-=Math.min(18,game.businessLevel*4); game.stress+=game.businessLevel;
  }
  const housing = game.home || game.rent;
  if(housing){game.money-=housing.monthly; notes.push(`Жильё: расходы ${money(housing.monthly)}.`)}
  else if(game.age>=25){game.health-=12;game.feeling-=8;notes.push("Нет жилья после 25 лет: здоровье и чувство жизни снизились.")}
  if(game.car){game.money-=game.car.monthly; notes.push(`Транспорт: расходы ${money(game.car.monthly)}.`)}
  if(game.children.length){const c=game.children.length*rand(8000,18000);game.money-=c;game.energy-=Math.min(20,game.children.length*5);notes.push(`Дети: расходы ${money(c)} и энергия.`)}
  if(game.relationship==="Брак"){game.energy-=8;game.feeling+=2}
  if(game.debt>0){const pay=Math.min(game.money,Math.ceil(game.debt*.035));game.money-=pay;game.debt-=pay;notes.push(`Кредит: платёж ${money(pay)}.`)}
  if(game.shares>0) game.money += rand(-Math.floor(game.shares*.03), Math.floor(game.shares*.06));
  if(game.crypto>0) game.money += rand(-Math.floor(game.crypto*.12), Math.floor(game.crypto*.16));
  if(rand(1,100)<45) notes.push(monthEvent());
  if(game.age>45&&!game.immortal) game.health-=rand(0,2);
  if(game.age>60&&!game.immortal) game.health-=rand(1,4);
  game.mental-=Math.floor(game.stress/25);
  game.energy=clamp(game.energy,0,100); normalize();
  log("Итог месяца", notes.join("\n")||"Месяц прошёл спокойно.");
  currentEvent=generateEvent(); checkDeath(); saveGame(); renderGame();
}
function monthEvent(){
  const list=[
    ()=>{const a=rand(3000,60000);game.money+=a;return`Случайность: удалось заработать ${money(a)}.`},
    ()=>{const a=rand(3000,80000);game.money-=Math.min(game.money,a);game.feeling-=3;return`Случайность: непредвиденные расходы ${money(a)}.`},
    ()=>{game.disease=choice(["Грипп","Травма","Стресс","Слабость"]);game.health-=rand(4,16);return`Случайность: болезнь — ${game.disease}.`},
    ()=>{game.friends+=1;game.charisma+=3;game.feeling+=3;return"Случайность: новое знакомство."},
    ()=>{if(game.relationship!=="Одинок"){game.love+=rand(-8,12);return"Случайность: отношения прошли проверку."} return"Случайность: спокойный личный месяц."},
    ()=>{if(game.business){game.businessRep+=5;return"Случайность: бизнес получил хорошую рекомендацию."} return"Случайность: появилась идея для бизнеса."},
  ];
  return choice(list)();
}
function generateEvent(){
  const A=game.age, events=[];
  if(A<=17) events.push(
    event("Выбор после школы","Учителя говорят, что пора думать о будущем. Одни одноклассники готовятся к экзаменам, другие ищут подработку, а кто-то мечтает о популярности.",[
      act("Готовиться к экзаменам",18,{mind:22,discipline:10,school:12},"Ты серьёзно занялся учёбой."),
      act("Искать подработку",20,{money:rand(5000,22000),discipline:5,stress:3},"Ты получил первые рабочие деньги."),
      act("Развивать блог",18,{fame:rand(8,30),charisma:8,skill:["Блогинг",10]},"Ты начал собирать аудиторию."),
      act("Проводить время с друзьями",14,{friends:1,feeling:12,charisma:5},"Ты укрепил дружбу.")
    ]),
    event("Компания зовёт гулять","Друзья зовут вечером на прогулку. Родители просят не задерживаться, потому что завтра важный день.",[
      act("Пойти и вернуться вовремя",12,{friends:1,feeling:10,parents:3,discipline:2},"Ты хорошо провёл время и не поссорился дома."),
      act("Задержаться допоздна",16,{feeling:14,charisma:6,parents:-8,discipline:-4},"Было весело, но дома был конфликт."),
      act("Остаться учиться",18,{mind:18,discipline:8,school:10},"Ты вложился в учёбу."),
      act("Пригласить всех к себе",14,{friends:2,parents:2,feeling:9},"Домашняя встреча прошла хорошо.",3000)
    ])
  );
  if(A>=18) events.push(
    event("Взрослая развилка","Теперь решения стали серьёзнее: работа, учёба, отношения, переезд или свой проект. Энергии много не бывает.",[
      act("Курсы для будущей работы",20,{mind:25,discipline:8,skill:["Программирование",12]},"Ты вложился в будущий доход.",30000),
      act("Искать стабильную работу",18,{discipline:6},"Ты начал искать постоянную работу."),
      act("Сфокусироваться на отношениях",14,{charisma:10,love:8,feeling:10},"Ты уделил внимание личной жизни."),
      act("Переехать",24,{city:"новый город",charisma:6,feeling:12},"Переезд дал новые возможности.",80000)
    ]),
    event("Баланс жизни","Работа, деньги, здоровье и отношения конкурируют за твоё время. Нужно выбрать, что важнее в этом месяце.",[
      act("Карьерный рывок",26,{career:16,mind:10,stress:8},"Ты вложился в карьеру."),
      act("Время с близкими",18,{feeling:18,love:8,parents:5,stress:-4},"Близкие почувствовали твоё внимание."),
      act("Здоровье и спорт",18,{health:18,mental:8,discipline:5},"Ты занялся здоровьем."),
      act("Бизнес-идея",28,{business:"coffee",businessRep:12,stress:6},"Ты запустил маленький бизнес.",180000)
    ])
  );
  events.push(event("Обычный месяц","Иногда жизнь меняется не от больших событий, а от того, как ты распоряжаешься обычным месяцем.",[
    act("Развиваться",18,{mind:15,discipline:6},"Ты сделал шаг к лучшей версии себя."),
    act("Общаться",14,{friends:1,charisma:6,feeling:8},"Общение сделало месяц теплее."),
    act("Зарабатывать",22,{money:rand(10000,80000),stress:5},"Ты использовал месяц для заработка."),
    act("Восстановиться",0,{energy:25,mental:8,stress:-10},"Ты восстановил силы.")
  ]));
  return choice(events);
}
function event(title,text,choices){return{title,text,choices}}
function act(title,cost,effects,result,moneyCost=0,need=null){return{title,cost,effects,result,money:moneyCost,need}}
function checkDeath(){
  if(!game || game.immortal || game.dead)return;
  if(game.health<=0) die("Здоровье упало до нуля.");
  else if(game.feeling<=0) die("Чувство жизни исчезло.");
  else if(game.mental<=0) die("Психика не выдержала.");
  else if(game.age>=80 && rand(1,100)<Math.min(70,(game.age-79)*5)) die("Смерть от старости.");
}
function ending(){
  if(game.immortal)return"Бессмертная легенда";
  if(game.money>=10000000&&game.businessLevel>=5)return"Магнат";
  if(game.fame>=1000)return"Знаменитость";
  if(game.children.length>=3)return"Большая семья";
  if(game.mind>=1500)return"Гений";
  if(game.feeling>=85)return"Счастливая жизнь";
  if(game.debt>game.money+500000)return"Жизнь в долгах";
  return"Обычная, но уникальная жизнь";
}
function die(reason){
  game.dead=true; game.ending=ending();
  const graves=load(GRAVES,[]);
  graves.push({name:game.name,age:game.age,money:game.money,ending:game.ending,reason,children:game.children.length,journal:game.journal.slice(0,20)});
  save(GRAVES,graves); saveGame();
  showModal("Жизнь завершена", `${reason}\n\nКонцовка: ${game.ending}\nВозраст: ${game.age}\nДеньги: ${money(game.money)}\nДети: ${game.children.length}`, [{t:"Новая игра",c:"green",fn:()=>{closeModal();showNewGame()}},{t:"Меню",c:"blue",fn:()=>{closeModal();renderMenu()}}]);
}
