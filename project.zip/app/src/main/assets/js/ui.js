
const app=$("#app"), modalRoot=$("#modalRoot"), modalCard=$("#modalCard"), toastBox=$("#toast"), music=$("#bgMusic");
function $(q){return document.querySelector(q)}
function vibrate(){if(settings.vibration&&navigator.vibrate)navigator.vibrate(20)}
function applyMusic(){if(settings.music){music.volume=.16;music.play().catch(()=>{})}else music.pause()}
function toast(t){toastBox.textContent=t;toastBox.classList.add("show");setTimeout(()=>toastBox.classList.remove("show"),1600)}
function renderMenu(){
  app.innerHTML=`<section class="screen menu"><div class="menu-wrap">
    <div class="title">LifePath</div><div class="subtitle">Пошаговый симулятор жизни</div>
    <div class="hero card"><img src="img/hero.png"><div><h2>Новая жизнь</h2><p>Детство, выборы, энергия месяца, работа, друзья, семья, бизнес, смерть и кладбище.</p></div></div>
    <button class="btn ${game?'blue':'gray'}" onclick="continueGame()">▶ Продолжить</button>
    <button class="btn green" onclick="showNewGame()">+ Новая игра</button>
    <button class="btn orange" onclick="showGraves()">▣ Кладбище</button>
    <button class="btn purple" onclick="showSettings()">⚙ Настройки</button>
  </div></section>`;
  applyMusic();
}
function showNewGame(){
  showModal("Новая жизнь", `<input id="nameInput" style="width:100%;height:54px;border-radius:18px;border:2px solid #dbe5f3;padding:0 14px;font-size:18px" value="Zeus" placeholder="Имя">`, [
    {t:"Мужской",c:"blue",fn:()=>startGame("Мужской")},
    {t:"Женский",c:"red",fn:()=>startGame("Женский")},
    {t:"Отмена",c:"gray",fn:closeModal}
  ], true);
}
function startGame(gender){const n=$("#nameInput").value.trim();closeModal();makeCharacter(n,gender);renderSetup();}
function continueGame(){if(!game)return toast("Сначала создай игру"); if(game.setup)return renderSetup(); if(!currentEvent)currentEvent=generateEvent(); renderGame();}
function renderSetup(){
  const spent=15-game.energy;
  app.innerHTML=`<section class="setup">
    <div class="setup-top"><div>${game.name} 0 лет</div><div class="center">⚡ ${game.energy}</div><div style="text-align:right">${money(0)}</div></div>
    <div class="setup-bars">
      <div class="setup-line"><div>❤️</div><div class="setup-track"><div class="setup-fill" style="width:${game.health}%"></div></div></div>
      <div class="setup-line"><div>🙂</div><div class="setup-track"><div class="setup-fill happy" style="width:${game.feeling}%"></div></div></div>
    </div>
    <div class="setup-actions">${DATA.setup.map(a=>`<button class="setup-action ${(game.setupPicks[a.id]||0)>0?'active':''} ${game.energy<a.cost?'disabled':''}" onclick="setupPick('${a.id}')">${a.title} (${game.setupPicks[a.id]||0})</button>`).join("")}</div>
    <div class="setup-footer"><button class="setup-advance" onclick="finishSetup()">Прожить 16 лет</button></div>
    ${game.setupIntro?`<div class="help">Добро пожаловать в жизнь, ${game.name}!<br><br>Распредели первые очки детства. От выбора зависят стартовые характеристики в 16 лет.<button onclick="game.setupIntro=false;saveGame();renderSetup()">Понятно</button></div>`:""}
  </section>`;
}
function stat(t,v){return`<div class="stat"><span>${t}</span><b>${v}</b></div>`}
function bar(t,v,c){v=clamp(v);return`<div><div class="barlabel"><span>${t}</span><span>${v}</span></div><div class="track"><div class="fill" style="width:${v}%;background:${c}"></div></div></div>`}
function renderGame(){
  if(!game)return renderMenu(); if(game.setup)return renderSetup(); if(!currentEvent)currentEvent=generateEvent(); normalize(); saveGame();
  const actions=tabActions(activeTab);
  app.innerHTML=`<section class="screen">
    <div class="top"><button class="round" onclick="renderMenu()">☰</button><div class="head"><h1>LifePath</h1><span>${game.age} лет • ${stage()}</span></div><button class="round" onclick="showAssets()">Активы</button></div>
    <div class="stats">${stat("Возраст",game.age)}${stat("Деньги",money(game.money))}${stat("Энергия",game.energy+"/"+game.energyMax)}${stat("Слава",game.fame)}</div>
    <div class="core">
      <section class="profile card"><img class="avatar" src="img/${game.gender==='Женский'?'avatar_girl.png':'avatar_boy.png'}"><div><div class="name">${game.name}</div><div class="info">${game.country} | ${game.city} | ${game.education}</div><div class="info">Работа: ${game.job?game.job.name:"Нет"} • Отношения: ${game.relationship}</div><div class="info">Друзья: ${game.friends} • Дети: ${game.children.length}</div><div class="bars">${bar("Здоровье",game.health,"#19a84d")}${bar("Чувство жизни",game.feeling,"#f59e0b")}${bar("Энергия",game.energy,"#2f7df4")}${bar("Психика",game.mental,"#a855f7")}</div></div></section>
      <section class="event card"><div class="tag">Событие месяца</div><h2>${currentEvent.title}</h2><p>${currentEvent.text}</p></section>
      <section class="panel card"><div class="tabs">${tabs().map(t=>`<button class="tab ${activeTab===t.id?'active':''}" onclick="activeTab='${t.id}';renderGame()">${t.name}</button>`).join("")}</div><div class="panel-title"><b>${tabs().find(t=>t.id===activeTab).title}</b><span>⚡ ${game.energy}/${game.energyMax}</span></div><div class="actions">${actions.slice(0,6).map((a,i)=>actionHtml(a,i)).join("")}</div></section>
    </div>
    <div class="bottom"><button class="smallbtn primary" onclick="showEvent()">Событие</button><button class="smallbtn" onclick="showDiary()">Дневник</button><button class="smallbtn" onclick="showStats()">Статы</button><button class="smallbtn month" onclick="nextMonth()">Месяц +</button></div>
  </section>`;
  applyMusic();
}
function tabs(){return[{id:"life",name:"Жизнь",title:"Жизнь и досуг"},{id:"food",name:"Еда",title:"Питание и здоровье"},{id:"study",name:"Учёба",title:"Учёба и навыки"},{id:"work",name:"Работа",title:"Работа и фриланс"},{id:"people",name:"Люди",title:"Друзья, семья, любовь"},{id:"home",name:"Дом",title:"Жильё и транспорт"},{id:"bank",name:"Банк",title:"Деньги и банк"},{id:"more",name:"Ещё",title:"Бизнес, питомцы, цели"}]}
function actionHtml(a,i){return`<button class="choice ${can(a)?'':'locked'}" onclick="doTabAction(${i})"><b>${a.title}</b><span>⚡ ${a.cost||0}${a.money?` • ${money(a.money)}`:""}</span></button>`}
function doTabAction(i){const a=tabActions(activeTab)[i]; if(!a)return; vibrate(); doAction(a)}
function showEvent(){showModal(currentEvent.title,currentEvent.text,currentEvent.choices.map(a=>({t:`${a.title} — ⚡${a.cost}${a.money?` • ${money(a.money)}`:""}`,c:can(a)?"blue":"gray",fn:()=>{closeModal();doAction(a)}})))}
function tabActions(tab){
  if(tab==="life")return[
    act("Отдохнуть",0,{energy:18,feeling:5,stress:-8,mental:5},"Ты восстановил силы."),
    act("Прогулка",8,{feeling:7,health:2,stress:-4},"Прогулка освежила мысли."),
    act("Хобби",12,{creativity:12,feeling:8,mental:4},"Хобби вдохновило."),
    act("Досуг",10,{feeling:10,stress:-6},"Ты перезагрузился."),
    act("Волонтёрство",14,{charisma:5,feeling:9},"Ты сделал полезное дело."),
    act("Самоанализ",10,{mental:10,discipline:3},"Ты лучше понял себя.")
  ];
  if(tab==="food")return[
    act("Домашняя еда",6,{food:"Домашнее",health:5,feeling:3},"Нормальное питание поддерживает силы.",3000),
    act("Фастфуд",4,{food:"Фастфуд",health:-4,feeling:5},"Быстро и вкусно, но вредно.",1500),
    act("Диета",10,{food:"Диета",health:12,looks:4,discipline:3},"Диета улучшила самочувствие.",18000),
    act("Зарядка",8,{health:8,discipline:3,stress:-2},"Зарядка дала бодрость."),
    act("Зал",16,{sport:"Зал",health:14,looks:7,discipline:5},"Тренировка была полезной.",9000),
    act("Лечение",12,{health:22,mental:5,disease:"Нет"},"Лечение помогло.",25000)
  ];
  if(tab==="study")return[
    act("Школа / учёба",18,{mind:18,discipline:8,school:10},"Ты серьёзно занялся учёбой."),
    act("Программирование",18,{skill:["Программирование",25]},"Ты изучал код.",5000),
    act("Английский",14,{skill:["Английский",22],charisma:3},"Английский стал лучше.",4000),
    act("Дизайн",14,{skill:["Дизайн",22],creativity:10},"Ты развил дизайн.",5000),
    act("Блогинг",12,{skill:["Блогинг",18],charisma:7,fame:3},"Ты изучал блогинг."),
    act("Финансы",12,{skill:["Финансы",18],mind:8},"Ты стал лучше понимать деньги.",4000)
  ];
  if(tab==="work"){
    const list=[
      act(game.age>=18?"Искать работу":"Подработка",18,{money:rand(3000,15000),discipline:4,stress:2},"Работа дала деньги."),
      act("Фриланс",22,{money:rand(12000,70000),mind:5,stress:4},"Фриланс принёс доход."),
      act("Вести блог",18,{fame:rand(5,25),charisma:6,skill:["Блогинг",10]},"Публикация получила отклик."),
      act("Повышение",14,{career:8,charisma:5,stress:3},"Ты обсудил рост."),
      act("Уволиться",0,{job:null,stress:-8,feeling:3},"Ты ушёл с работы."),
    ];
    DATA.jobs.forEach(j=>list.push(act("Устроиться: "+j.name,16,{job:j.id},`Ты устроился: ${j.name}.`,0,{age:j.age,...j.need})));
    return list;
  }
  if(tab==="people")return[
    act("Познакомиться",10,{acquaintances:rand(1,3),charisma:5,feeling:4},"Ты познакомился с новыми людьми."),
    act("Друзья",14,{friends:1,feeling:10,stress:-5,charisma:3},"Встреча подняла настроение."),
    act("Семья",12,{parents:10,feeling:8,mental:3},"Семейный разговор был тёплым."),
    act("Искать любовь",12,{partner:1,charisma:8,feeling:6},"Ты встретил интересного человека.",0,{age:16}),
    act("Свидание",14,{love:16,feeling:12,charisma:4},"Свидание прошло хорошо.",5000),
    act("Ребёнок",18,{child:1,feeling:18,stress:5},"В семье появился ребёнок.",50000,{age:18})
  ];
  if(tab==="home")return[
    ...DATA.properties.map(p=>act(p.name,5,{[p.kind]:p.id,feeling:5},`Теперь у тебя: ${p.name}.`,p.price,{age:18})),
    ...DATA.cars.slice(0,2).map(c=>act(c.name,6,{car:c.id,feeling:4},`Куплен транспорт: ${c.name}.`,c.price,{age:18})),
  ];
  if(tab==="bank")return[
    act("Акции",6,{shares:50000},"Ты купил акции.",50000,{age:18}),
    act("Крипта",8,{crypto:50000},"Ты купил криптовалюту.",50000,{age:18}),
    act("Кредит 500к",2,{money:500000,debt:650000,stress:6},"Банк выдал кредит.",0,{age:18}),
    act("Погасить 100к",4,{debt:-100000,stress:-4},"Ты погасил долг.",100000,{age:18}),
    act("Финансовый план",8,{skill:["Финансы",12],discipline:5,stress:-3},"Ты навёл порядок."),
    act("Копить",6,{money:rand(5000,25000),discipline:4,feeling:-1},"Ты отложил деньги.")
  ];
  return[
    ...DATA.businesses.slice(0,2).map(b=>act("Бизнес: "+b.name,28,{business:b.id,businessRep:10,stress:5},`Ты открыл: ${b.name}.`,b.price,{age:18})),
    act("Улучшить бизнес",24,{businessLevel:1,businessRep:18,stress:5},"Бизнес стал сильнее.",200000,{age:18}),
    act("Путешествие",24,{feeling:20,charisma:5,stress:-8},"Путешествие стало ярким событием.",90000),
    act("Питомец",10,{pet:"Кот",feeling:10,stress:-5},"Питомец сделал дом теплее.",15000),
    act("Бессмертие",40,{immortal:true,health:100,mental:100,feeling:100},"Ты стал бессмертным.",10000000,{age:45,mind:1000})
  ];
}
function showModal(title,text,buttons=[],raw=False){
  modalCard.innerHTML=`<h2>${title}</h2><div class="line"></div><div class="modal-text">${text}</div><div class="modal-list">${buttons.map((b,i)=>`<button class="btn ${b.c||'blue'}" onclick="modalClick(${i})">${b.t}</button>`).join("")}</div>`;
  window._modalButtons=buttons;modalRoot.classList.remove("hidden");
}
function modalClick(i){const b=window._modalButtons[i]; if(b&&b.fn)b.fn()}
function closeModal(){modalRoot.classList.add("hidden")}
function showDiary(){showModal("Дневник",game.journal.length?game.journal.slice(0,45).map(j=>`• ${j.age} лет: ${j.title}\n${j.text}`).join("\n\n"):"Пока записей нет.")}
function showStats(){showModal("Статы",`Имя: ${game.name}\nВозраст: ${game.age}\nДеньги: ${money(game.money)}\nЭнергия: ${game.energy}/100\nЗдоровье: ${game.health}\nЧувство жизни: ${game.feeling}\nПсихика: ${game.mental}\nУм: ${game.mind}\nХаризма: ${game.charisma}\nТворчество: ${game.creativity}\nДисциплина: ${game.discipline}\nДрузья: ${game.friends}\nРабота: ${game.job?game.job.name:"Нет"}\nОтношения: ${game.relationship}\nДети: ${game.children.length}\nБизнес: ${game.business?game.business.name:"Нет"}\nДолг: ${money(game.debt)}`)}
function showAssets(){showModal("Активы",`Жильё: ${game.home?game.home.name:(game.rent?game.rent.name:"Нет")}\nТранспорт: ${game.car?game.car.name:"Нет"}\nБизнес: ${game.business?game.business.name:"Нет"}\nАкции: ${money(game.shares)}\nКрипта: ${money(game.crypto)}\nДолг: ${money(game.debt)}\nПитомцы: ${game.pets.length?game.pets.join(", "):"Нет"}`)}
function showGraves(){const g=load(GRAVES,[]);showModal("Кладбище",g.length?g.map(x=>`🪦 ${x.name}, ${x.age} лет — ${x.ending}`).join("\n\n"):"Пока прошлых жизней нет.")}
function showSettings(){showModal("Настройки",`Музыка: ${settings.music?"вкл":"выкл"}\nВибрация: ${settings.vibration?"вкл":"выкл"}`,[{t:"Музыка",c:"purple",fn:()=>{settings.music=!settings.music;save(SETTINGS,settings);applyMusic();showSettings()}},{t:"Вибрация",c:"orange",fn:()=>{settings.vibration=!settings.vibration;save(SETTINGS,settings);showSettings()}},{t:"Закрыть",c:"blue",fn:closeModal}])}
window.NativeBack=function(){if(!modalRoot.classList.contains("hidden"))closeModal();else renderMenu()}
renderMenu();
