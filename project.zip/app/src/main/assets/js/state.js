
const SAVE="lifepath_clean_save_v1", GRAVES="lifepath_clean_graves_v1", SETTINGS="lifepath_clean_settings_v1";
let game = load(SAVE,null);
let settings = load(SETTINGS,{music:true,vibration:true});
let activeTab = "life";
let currentEvent = null;
function load(k,f){try{return JSON.parse(localStorage.getItem(k))??f}catch(e){return f}}
function save(k,v){localStorage.setItem(k,JSON.stringify(v))}
function saveGame(){if(game) save(SAVE,game)}
function clamp(v,min=0,max=100){return Math.max(min,Math.min(max,Math.round(v)))}
function rand(a,b){return Math.floor(Math.random()*(b-a+1))+a}
function choice(a){return a[Math.floor(Math.random()*a.length)]}
function money(n){return Math.round(n).toLocaleString("ru-RU")+" ₽"}
function stage(){if(!game)return"";if(game.immortal)return"Бессмертие";if(game.age<18)return"Юность";if(game.age<26)return"Молодость";if(game.age<60)return"Взрослая жизнь";return"Старость"}
function makeCharacter(name, gender){
  const g = {
    name:name||choice(gender==="Женский"?["Анна","Мария","Катя","Лена"]:["Денис","Алексей","Максим","Иван"]),
    gender, setup:true, age:0, month:0, energy:15, energyMax:15, money:0,
    country:choice(["Россия","Германия","США","Япония"]), city:"родной город",
    health:50, feeling:20, happiness:20, mental:50, looks:35,
    mind:0, charisma:0, creativity:0, discipline:0, fame:0, stress:0,
    education:"Нет", school:0, skills:{}, friends:0, acquaintances:0, parents:60,
    job:null, career:0, jobExp:0, business:null, businessLevel:0, businessRep:0,
    relationship:"Одинок", partner:null, love:0, children:[],
    home:null, rent:null, car:null, debt:0, shares:0, crypto:0,
    food:"Обычное", sport:"Нет", pets:[], inventory:[], journal:[], achievements:[],
    disease:"Нет", immortal:false, dead:false, ending:"", setupPicks:{}, setupIntro:true
  };
  DATA.skills.forEach(s=>g.skills[s]=0);
  game=g; currentEvent=null; saveGame();
}
function log(title,text){if(!game)return;game.journal.unshift({age:game.age,month:game.month,title,text});if(game.journal.length>160)game.journal.pop()}
