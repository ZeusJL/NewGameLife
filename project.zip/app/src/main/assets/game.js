const $ = q => document.querySelector(q);
const app = $("#app"), modalRoot = $("#modalRoot"), modalCard = $("#modalCard"), music = $("#bgMusic"), toastBox = $("#toast");
const SAVE="newlife_webview_save_v13", GRAVES="newlife_webview_graves_v13", SETTINGS="newlife_webview_settings_v13";
let settings = loadJSON(SETTINGS,{music:true,sound:true,vibration:true,autosave:true,cloud:false,google:false});
let game = loadJSON(SAVE,null);
let currentEvent = null;

function loadJSON(k,f){try{return JSON.parse(localStorage.getItem(k))??f}catch(e){return f}}
function saveJSON(k,v){localStorage.setItem(k,JSON.stringify(v))}
function clamp(v,min=0,max=100){return Math.max(min,Math.min(max,Math.round(v)))}
function rand(a,b){return Math.floor(Math.random()*(b-a+1))+a}
function choice(a){return a[Math.floor(Math.random()*a.length)]}
function money(n){return Math.round(n).toLocaleString("ru-RU")+" ₽"}
function vibrate(ms=22){if(settings.vibration&&navigator.vibrate)navigator.vibrate(ms)}
function applyMusic(){if(settings.music){music.volume=.18;music.play().catch(()=>{})}else music.pause()}
function saveGame(){if(settings.autosave&&game)saveJSON(SAVE,game)}
function toast(t){toastBox.textContent=t;toastBox.classList.add("show");setTimeout(()=>toastBox.classList.remove("show"),1800)}
function particles(){return `<div class="particles">${Array.from({length:22},()=>`<i style="left:${rand(2,98)}%;bottom:${rand(-20,90)}%;animation-duration:${rand(5,12)}s;animation-delay:${rand(0,60)/10}s"></i>`).join("")}</div>`}

const MONTHS = ["Январь","Февраль","Март","Апрель","Май","Июнь","Июль","Август","Сентябрь","Октябрь","Ноябрь","Декабрь"];

const JOBS = [
 {id:"courier",name:"Курьер",salary:35000,energy:4,need:{age:16},tags:["простая"],desc:"быстрая работа без опыта"},
 {id:"cashier",name:"Кассир",salary:42000,energy:4,need:{age:18},tags:["простая"],desc:"стабильная работа в магазине"},
 {id:"driver",name:"Водитель",salary:65000,energy:5,need:{age:18,discipline:50},tags:["транспорт"],desc:"дорога, клиенты и график"},
 {id:"designer",name:"Дизайнер",salary:90000,energy:4,need:{age:18,creativity:120},tags:["творчество"],desc:"логотипы, сайты и визуал"},
 {id:"programmer",name:"Программист",salary:150000,energy:5,need:{age:18,mind:220},tags:["it"],desc:"код, проекты и дедлайны"},
 {id:"doctor",name:"Врач",salary:180000,energy:6,need:{age:22,education:"Медицина",mind:300},tags:["медицина"],desc:"ответственная медицинская работа"},
 {id:"lawyer",name:"Юрист",salary:170000,energy:5,need:{age:22,education:"Юриспруденция",charisma:120},tags:["право"],desc:"договоры, суды и клиенты"},
 {id:"blogger",name:"Блогер",salary:0,energy:3,need:{age:14,charisma:80},tags:["слава"],desc:"доход зависит от славы"},
 {id:"actor",name:"Актёр",salary:80000,energy:5,need:{age:16,charisma:180,creativity:120},tags:["слава"],desc:"кастинги и съёмки"},
 {id:"scientist",name:"Учёный",salary:130000,energy:5,need:{age:23,education:"Наука",mind:550},tags:["наука"],desc:"исследования и гранты"},
 {id:"director",name:"Директор",salary:260000,energy:6,need:{age:25,mind:450,charisma:260},tags:["карьера"],desc:"управление людьми"},
 {id:"politician",name:"Политик",salary:300000,energy:7,need:{age:25,fame:400,charisma:400},tags:["власть"],desc:"влияние, риски и репутация"},
];

const PROPERTIES = [
 {id:"room",name:"Комната",price:120000,upkeep:1500,happiness:3},
 {id:"flat",name:"Квартира",price:850000,upkeep:5500,happiness:8},
 {id:"house",name:"Дом",price:3500000,upkeep:15000,happiness:15},
 {id:"villa",name:"Вилла",price:18000000,upkeep:70000,happiness:25},
];
const CARS = [
 {id:"oldcar",name:"Старое авто",price:150000,upkeep:3500,fame:2},
 {id:"car",name:"Хорошая машина",price:900000,upkeep:12000,fame:8},
 {id:"sportcar",name:"Спорткар",price:12000000,upkeep:90000,fame:25},
];

function stage(){if(game.immortal)return"Бессмертный";if(game.age<=2)return"Младенец";if(game.age<=6)return"Детство";if(game.age<=13)return"Школа";if(game.age<=17)return"Подросток";if(game.age<=25)return"Молодость";if(game.age<=59)return"Взрослая жизнь";return"Старость"}
function ageMonth(){return `${game.age} лет • ${MONTHS[game.month]} • ${stage()}`}
function renderMenu(){
 app.innerHTML=`<section class="screen menu-screen">${particles()}<div class="menu-wrap slide-up">
  <div class="title">НОВАЯ ЖИЗНЬ</div><div class="subtitle">Пошаговый симулятор судьбы</div>
  <div class="hero card floaty"><img src="img/hero.png"><div><h2>Story Edition</h2><p>Каждый месяц — энергия, выборы, семья, друзья, работа, случайные события и разные концовки.</p></div></div>
  <div class="menu-buttons">
   <button class="big-btn ${game?'btn-blue':'btn-gray'}" onclick="continueGame()">▶ Продолжить игру</button>
   <button class="big-btn btn-green pulse" onclick="showNewGame()">+ Новая игра</button>
   <button class="big-btn btn-orange" onclick="showGraves()">▣ Ваши игры</button>
   <button class="big-btn btn-purple" onclick="showSettings()">⚙ Настройки</button>
   <button class="big-btn btn-red" onclick="tryExit()">⏻ Выйти</button>
  </div><div class="brand">LifeSim Studio • Energy Story v13</div></div></section>`;
 applyMusic();
}
function continueGame(){vibrate();if(!game)return toast("Сначала создай новую игру"); if(!currentEvent) currentEvent=generateEvent(); renderGame();}
function newGame(name="",gender="Мужской"){
 let r=rand(1,100), fam="Обычная семья", start=rand(5000,30000), happy=75, fame=0, familyMoney=50, support=50;
 if(r<=18){fam="Бедная семья";start=rand(0,8000);happy-=4;familyMoney=15;support=65}
 if(r>=85){fam="Богатая семья";start=rand(70000,250000);happy+=8;fame+=5;familyMoney=90;support=45}
 game={name:name||choice(gender==="Женский"?["Анна","Мария","Ольга","Катя","Ира","Лена"]:["Денис","Алексей","Максим","Иван","Никита","Дима"]),gender,
  country:choice(["Россия","США","Германия","Бразилия","Япония"]),city:choice(["обычный город","большой город","маленький город","новый город"]),
  age:0,month:0,totalMonths:0,level:1,xp:0,money:start,monthlyEnergy:20,energy:20,
  health:100,happiness:happy,mental:80,looks:rand(30,90),mind:0,charisma:0,creativity:0,discipline:0,luck:rand(0,3),fame,
  family_status:fam,familyMoney,support,parents:100,sibling:rand(1,100)>60?choice(["брат","сестра"]):"Нет",education:"Нет",school:0,university:0,
  job:null,jobExp:0,career:0,business:0,businessName:"",businessReputation:0,shares:0,crypto:0,debt:0,
  friends:0,bestFriend:"Нет",relationship:"Одинок",partner:"",love:0,children:[],pet:"Нет",
  home:null,car:null,disease:"Нет",badHabits:0,stress:0,criminal:0,karma:0,
  journal:[],achievements:[],flags:{},immortal:false,game_over:false,death_reason:"",ending:"",lastResult:"Ты родился. Начинается новая жизнь."
 };
 log("Рождение",`Ты родился в стране ${game.country}. Семья: ${game.family_status}.`);
 currentEvent=generateEvent();saveGame();renderGame();
}
function log(title,text){game.journal.unshift({m:game.totalMonths,age:game.age,title,text}); if(game.journal.length>120)game.journal.pop();}
function bar(n,v,c){v=clamp(v);return`<div><div class="bar-label"><span>${n}</span><span>${v}/100</span></div><div class="track"><div class="fill" style="width:${v}%;background:${c}"></div></div></div>`}
function mini(t,v,b){return`<div class="mini" style="background:${b}"><span>${t}</span><b>${v}</b></div>`}
function renderGame(){
 if(!game)return renderMenu(); if(!currentEvent)currentEvent=generateEvent(); checkLimits(); checkAchievements(); saveGame();
 let jobName=game.job?game.job.name:"Нет";
 app.innerHTML=`<section class="screen game-screen">
  <div class="topbar"><button class="round-btn" onclick="renderMenu()">☰</button><div class="head-title"><h1>НОВАЯ ЖИЗНЬ</h1><span>${ageMonth()}</span></div><button class="round-btn shop-btn" onclick="showAssets()">Активы</button></div>
  <div class="pills"><div class="pill">${game.age} лет</div><div class="pill money">${money(game.money)}</div><div class="pill energy">Энергия ${game.energy}/${game.monthlyEnergy}</div><div class="pill fame">Слава ${game.fame}</div></div>
  <div class="scroll">
   <section class="profile card slide-up"><div class="profile-top"><img class="avatar floaty" src="img/${game.gender==='Женский'?'avatar_girl.png':'avatar_boy.png'}"><div><div class="name">${game.name}</div><div class="info">${game.country} | ${game.city}</div><div class="info">Семья: ${game.family_status}</div><div class="info">Работа: ${jobName} | Отношения: ${game.relationship}</div></div></div>
    <div class="bars">${bar("Здоровье",game.health,"#19a84d")}${bar("Счастье",game.happiness,"#f59e0b")}${bar("Энергия",game.energy/game.monthlyEnergy*100,"#2f7df4")}${bar("Психика",game.mental,"#a855f7")}</div>
    <div class="mini-stats">${mini("Ум",game.mind,"#e9f5ff")}${mini("Харизма",game.charisma,"#fff0f7")}${mini("Творч.",game.creativity,"#fff8df")}${mini("Дисцип.",game.discipline,"#f0edff")}${mini("Образ.",game.education,"#f0edff")}${mini("Друзья",game.friends,"#eaf8ef")}${mini("Бизнес",game.business,"#e7f8fb")}${mini("Дети",game.children.length,"#fff0f5")}</div></section>
   <section class="energy-card card slide-up"><div class="energy-row"><span>Энергия месяца</span><span>${game.energy}/${game.monthlyEnergy}</span></div><div class="track"><div class="fill" style="width:${clamp(game.energy/game.monthlyEnergy*100)}%;background:#f59e0b"></div></div><div class="energy-grid" style="margin-top:10px"><div class="energy-note">Работа и семья каждый месяц тратят энергию автоматически.</div><div class="energy-note">Когда энергия закончится — проживи следующий месяц.</div></div></section>
   <section class="event-card card slide-up"><div class="tag">Событие жизни</div><div class="event-title">${currentEvent.title}</div><div class="event-text">${currentEvent.text}</div><div class="event-meta">Тип: ${currentEvent.type} • Возраст: ${stage()}</div></section>
   <section class="choices card slide-up"><h3>Что выбрать?</h3><div class="choice-list">${currentEvent.choices.map((c,i)=>choiceHTML(c,i)).join("")}</div></section>
   <section class="quick card slide-up"><h3>Быстрые действия месяца</h3><div class="quick-grid">
    <button class="quick-btn btn-blue" onclick="openCategory('life')">Жизнь<small>отдых, хобби, переезды</small></button>
    <button class="quick-btn btn-purple" onclick="openCategory('study')">Учёба<small>школа, курсы, университет</small></button>
    <button class="quick-btn btn-green" onclick="openCategory('work')">Работа<small>профессии и фриланс</small></button>
    <button class="quick-btn btn-red" onclick="openCategory('people')">Люди<small>друзья, семья, дети</small></button>
    <button class="quick-btn btn-orange" onclick="openCategory('shop')">Имущество<small>дом, транспорт, магазин</small></button>
    <button class="quick-btn btn-purple" onclick="nextMonth()">Следующий месяц<small>расходы, работа, события</small></button>
   </div></section>
  </div>
  <nav class="bottom-nav"><button class="nav-btn active" onclick="renderGame()">Жизнь</button><button class="nav-btn" onclick="showDiary()">Дневник</button><button class="nav-btn" onclick="showStats()">Статы</button><button class="nav-btn" onclick="showGoals()">Цели</button></nav>
 </section>`;
 applyMusic();
}
function choiceHTML(c,i){
 let ok = canChoose(c);
 return `<button class="choice-btn ${ok?'':'locked'}" onclick="choose(${i})"><b>${c.text}</b><span>${costText(c)}${c.hint? " • "+c.hint:""}</span></button>`;
}
function costText(c){let a=[]; if(c.cost)a.push(`⚡ ${c.cost}`); if(c.money)a.push(`${money(c.money)}`); if(c.need)a.push("есть условия"); return a.join(" • ") || "бесплатно"}
function canChoose(c){
 if(c.cost && game.energy < c.cost) return false;
 if(c.money && game.money < c.money) return false;
 if(c.need){
   for(const [k,v] of Object.entries(c.need)){
     if(k==="age" && game.age < v) return false;
     if(k==="job" && (!game.job || game.job.id!==v)) return false;
     if(k==="relationship" && game.relationship!==v) return false;
     if(k==="education" && game.education!==v) return false;
     if(typeof game[k]==="number" && game[k] < v) return false;
   }
 }
 return true;
}
function choose(i){
 let c=currentEvent.choices[i]; if(!c)return;
 if(!canChoose(c)){toast("Не хватает энергии, денег или условий");return}
 vibrate(); if(c.cost)game.energy-=c.cost; if(c.money)game.money-=c.money;
 let res = applyEffects(c.effects||{}, c.result||"Выбор сделан.");
 log(currentEvent.title, `${c.text}: ${res}`);
 game.lastResult = res;
 currentEvent = generateEvent();
 checkDeath(); renderGame();
}
function applyEffects(e, result){
 for(const [k,v] of Object.entries(e)){
   if(k==="flag") game.flags[v]=true;
   else if(k==="job") game.job=JOBS.find(j=>j.id===v)||game.job;
   else if(k==="home") game.home=PROPERTIES.find(p=>p.id===v)||game.home;
   else if(k==="car") game.car=CARS.find(c=>c.id===v)||game.car;
   else if(k==="friend"){game.friends+=v; if(game.bestFriend==="Нет")game.bestFriend=choice(["Артём","Саша","Макс","Ира","Катя","Олег","Миша","Лена"]);}
   else if(k==="child"){game.children.push({name:choice(["Миша","Аня","Илья","София","Марк","Алиса"]),age:0});}
   else if(k==="partner"){game.partner=choice(["Алекс","Саша","Марина","Оля","Ира","Никита","Максим","Катя","Лена","Дима"]);game.relationship="В отношениях";game.love=rand(35,70);}
   else if(k==="businessName") game.businessName=v;
   else if(k==="education") game.education=v;
   else if(typeof game[k]==="number") game[k]+=v;
   else game[k]=v;
 }
 addXP(8 + (e.mind||0) + (e.discipline||0) + (e.charisma||0));
 checkLimits();
 return result;
}
function addXP(n){game.xp += Math.max(0,Math.round(n)); while(game.xp>=game.level*100){game.xp-=game.level*100;game.level++;game.money+=game.level*700;game.happiness+=2;}}
function nextMonth(){
 vibrate();
 let notes=[];
 game.totalMonths++; game.month++; if(game.month>=12){game.month=0; game.age++; yearlyUpdate(notes);}
 game.energy=game.monthlyEnergy;
 // auto responsibilities
 if(game.job){
   game.energy -= game.job.energy;
   let salary = calcSalary();
   game.money += salary;
   game.jobExp += rand(2,5);
   game.career += rand(1,3);
   game.stress += Math.max(1,game.job.energy-3);
   notes.push(`Работа «${game.job.name}» принесла ${money(salary)} и забрала ${game.job.energy} энергии.`);
 }
 if(game.business>0){
   let profit = game.business*rand(18000,65000) + game.businessReputation*800;
   let risk = rand(1,100);
   if(risk<18){profit = -Math.floor(profit*.45); notes.push("В бизнесе случились непредвиденные расходы.");}
   game.money += profit; game.stress += game.business; notes.push(`Бизнес: ${profit>=0?"+":""}${money(profit)}.`);
 }
 if(game.home){game.money-=game.home.upkeep; notes.push(`Жильё: расходы ${money(game.home.upkeep)}.`);}
 if(game.car){game.money-=game.car.upkeep; notes.push(`Транспорт: расходы ${money(game.car.upkeep)}.`);}
 if(game.children.length){let cost=game.children.length*rand(7000,18000);game.money-=cost;game.energy-=Math.min(5,game.children.length);game.happiness+=2;notes.push(`Дети: расходы ${money(cost)} и забота.`);}
 if(game.relationship==="Брак"){game.energy-=2;game.happiness+=rand(0,3); if(rand(1,100)<12){game.love-=rand(3,10);notes.push("В семье возник небольшой конфликт.");}}
 if(game.debt>0){let pay=Math.min(game.money, Math.ceil(game.debt*.035)); game.money-=pay; game.debt-=pay; notes.push(`Кредит: платёж ${money(pay)}.`);}
 if(game.shares>0) game.money += rand(-Math.floor(game.shares*.035), Math.floor(game.shares*.07));
 if(game.crypto>0) game.money += rand(-Math.floor(game.crypto*.12), Math.floor(game.crypto*.16));
 game.energy=clamp(game.energy,0,game.monthlyEnergy);
 game.stress=clamp(game.stress + rand(-2,3),0,100);
 game.mental-=Math.floor(game.stress/20);
 game.happiness-=game.debt>0?2:0;
 if(game.age>35&&!game.immortal)game.health-=rand(0,1);
 if(game.age>60&&!game.immortal)game.health-=rand(1,3);
 if(game.disease!=="Нет"&&!game.immortal)game.health-=rand(2,7);
 if(rand(1,100)<30) notes.push(randomMonthlyEvent());
 game.children.forEach(ch=>{ if(game.month===0) ch.age++; });
 checkDeath();
 let summary = notes.length?notes.join("\n"):"Месяц прошёл спокойно.";
 game.lastResult=summary; log("Новый месяц",summary);
 currentEvent=generateEvent();
 renderGame();
}
function yearlyUpdate(notes){
 if(game.age===3)notes.push("Ты стал старше: теперь детство открывает новые возможности.");
 if(game.age===7){game.education="Школа";notes.push("Ты пошёл в школу.");}
 if(game.age===14)notes.push("Начался подростковый возраст: появляются друзья, любовь и подработки.");
 if(game.age===18)notes.push("Ты стал совершеннолетним: доступны работа, жильё, отношения и переезды.");
 if(game.age===60)notes.push("Началась старость. Здоровье будет снижаться быстрее.");
}
function calcSalary(){
 if(!game.job)return 0;
 if(game.job.id==="blogger") return Math.max(0, game.fame*rand(250,800)+game.charisma*80+rand(-10000,50000));
 let bonus=1+game.career/120+game.mind/2000+game.fame/3000;
 return Math.round(game.job.salary*bonus);
}
function randomMonthlyEvent(){
 let pool=[
  ()=>{let a=rand(2000,50000);game.money+=a;return`Случайность: повезло заработать ${money(a)}.`},
  ()=>{let a=rand(3000,80000);game.money-=Math.min(game.money,a);game.happiness-=3;return`Случайность: непредвиденные расходы ${money(a)}.`},
  ()=>{game.disease=choice(["Грипп","Травма","Стресс","Аллергия"]);game.health-=rand(4,15);return`Случайность: болезнь — ${game.disease}.`},
  ()=>{game.friends+=1;game.charisma+=3;return"Случайность: новое знакомство."},
  ()=>{game.fame+=rand(3,15);return"Случайность: тебя заметили в соцсетях."},
  ()=>{game.familyMoney+=rand(-5,8);return"Случайность: в семье изменилось финансовое положение."},
  ()=>{if(game.relationship!=="Одинок"){game.love+=rand(-8,12);return"Случайность: отношения прошли проверку."} return"Случайность: спокойный личный месяц."},
 ];
 return choice(pool)();
}
function generateEvent(){
 let pool=[];
 const A=game.age;
 const common = [
  ev("Внутренний выбор","Ты чувствуешь, что жизнь постепенно меняется. Этот месяц можно потратить на себя, людей или развитие.","личное",[
   ch("Разобраться в себе",2,{mental:8,happiness:3,discipline:2},"Ты лучше понял свои желания."),
   ch("Провести время с близкими",3,{happiness:7,parents:4,charisma:2},"Тёплый месяц с близкими."),
   ch("Учиться новому",4,{mind:10,discipline:3},"Ты прокачал знания."),
   ch("Ничего не менять",0,{happiness:2},"Иногда спокойствие тоже нужно.")
  ]),
  ev("Неожиданная возможность","Появилась возможность попробовать что-то новое. Это может стать маленьким поворотом судьбы.","случайное",[
   ch("Согласиться",4,{charisma:5,mind:5,fame:2},"Ты получил новый опыт."),
   ch("Осторожно изучить",2,{mind:7,discipline:2},"Ты не бросился в риск, но узнал полезное."),
   ch("Отказаться",0,{mental:3},"Ты решил не распыляться."),
  ])
 ];
 if(A<=2) pool.push(
  ev("Первые шаги","Ты пытаешься сделать первые шаги. Родители внимательно наблюдают.","детство",[
   ch("Стараться идти самому",3,{health:4,discipline:2,parents:3},"Ты сделал несколько уверенных шагов."),
   ch("Ползти к игрушке",2,{happiness:6,creativity:1},"Игрушка оказалась важнее победы."),
   ch("Позвать родителей",1,{parents:6,charisma:1},"Родители улыбнулись и поддержали тебя.")
  ]),
  ev("Первые слова","Ты начинаешь повторять звуки и слова. В доме все ждут первого осмысленного слова.","детство",[
   ch("Повторять за родителями",3,{mind:5,charisma:2,parents:5},"Ты сказал что-то похожее на слово."),
   ch("Смеяться и играть",2,{happiness:8,parents:3},"Дома стало веселее."),
   ch("Молчать и наблюдать",1,{mind:4,mental:2},"Ты внимательно изучал мир.")
  ])
 );
 if(A>=3&&A<=6) pool.push(
  ev("Детская площадка","На площадке дети зовут тебя играть, но незнакомая компания немного пугает.","детство",[
   ch("Играть вместе",3,{friend:1,charisma:5,happiness:8},"У тебя появился новый приятель."),
   ch("Играть одному",2,{creativity:6,mental:3},"Ты придумал собственную игру."),
   ch("Попросить родителей помочь",1,{parents:5,charisma:2},"Родители помогли познакомиться.")
  ]),
  ev("Кружок развития","Родители предлагают записать тебя в кружок. Выбор может повлиять на характер.","развитие",[
   ch("Спорт",4,{health:8,discipline:5},"Спорт сделал тебя активнее."),
   ch("Рисование",4,{creativity:10,happiness:4},"Ты начал проявлять творчество."),
   ch("Подготовка к школе",4,{mind:10,discipline:3},"Учёба далась легче."),
   ch("Ничего не хочу",0,{happiness:5},"Ты просто наслаждался детством.")
  ])
 );
 if(A>=7&&A<=13) pool.push(
  ev("Первый день в школе","Учитель задаёт вопросы, а одноклассники смотрят друг на друга с интересом.","школа",[
   ch("Учиться внимательно",4,{mind:12,discipline:5,school:8},"Ты хорошо проявил себя на уроках."),
   ch("Познакомиться с классом",3,{friend:2,charisma:8,happiness:5},"Ты нашёл общий язык с ребятами."),
   ch("Сидеть тихо",1,{mental:4,mind:3},"Ты спокойно привыкал к школе."),
   ch("Баловаться",3,{happiness:8,discipline:-5,school:-2},"Было весело, но учитель сделал замечание.")
  ]),
  ev("Контрольная работа","В классе контрольная. Ты можешь подготовиться или попытаться выкрутиться.","школа",[
   ch("Учить весь вечер",5,{mind:14,discipline:8,school:12,energy:-1},"Ты написал контрольную хорошо."),
   ch("Списать",2,{school:4,criminal:2,discipline:-4},"Получилось, но ты рисковал."),
   ch("Попросить помощи у друга",3,{friend:1,mind:7,charisma:3},"Друг объяснил сложную тему."),
   ch("Не готовиться",0,{happiness:4,school:-5},"Свободный вечер, но оценка хуже.")
  ])
 );
 if(A>=14&&A<=17) pool.push(
  ev("Подростковая компания","Компания зовёт гулять вечером. Родители просят вернуться пораньше.","подросток",[
   ch("Пойти и вернуться вовремя",3,{friend:2,charisma:7,happiness:7,parents:2},"Ты хорошо провёл время и не поссорился с родителями."),
   ch("Задержаться допоздна",4,{happiness:12,charisma:5,parents:-8,discipline:-4},"Было весело, но дома был конфликт."),
   ch("Остаться дома и учиться",4,{mind:12,discipline:7,school:8},"Ты вложился в будущее."),
   ch("Начать вести блог",5,{fame:rand(5,20),creativity:8,charisma:4},"Ты сделал первые публикации.")
  ]),
  ev("Первая симпатия","Тебе нравится человек из окружения. Можно сделать шаг или промолчать.","отношения",[
   ch("Познакомиться ближе",3,{partner:1,charisma:7,happiness:8},"Началось тёплое общение."),
   ch("Написать сообщение",2,{charisma:4,love:10},"Вы начали переписываться."),
   ch("Промолчать",0,{mental:2},"Ты решил не торопиться."),
  ]),
  ev("Выбор после школы","Пора думать о будущем: работа, образование или популярность.","будущее",[
   ch("Готовиться к университету",5,{mind:18,discipline:8,school:12},"Ты сделал ставку на образование."),
   ch("Искать подработку",4,{money:rand(5000,25000),discipline:3},"Ты заработал первые деньги."),
   ch("Развивать блог",5,{fame:rand(10,35),creativity:10,charisma:8},"Ты стал заметнее в сети."),
   ch("Жить моментом",2,{happiness:12,discipline:-3},"Свобода была приятной.")
  ])
 );
 if(A>=18&&A<=25) pool.push(
  ev("Взрослая жизнь","Перед тобой открываются взрослые решения: образование, работа, отношения, переезд.","молодость",[
   ch("Поступить в университет",6,{education:"Университет",mind:30,discipline:10}, "Ты поступил в университет.", {money:50000}),
   ch("Найти работу",4,{flag:"want_job",discipline:5},"Ты начал искать работу."),
   ch("Сфокусироваться на отношениях",3,{charisma:10,happiness:8,love:8},"Ты уделил внимание личной жизни."),
   ch("Переехать в новый город",5,{city:"новый город",happiness:5,charisma:5}, "Переезд дал новые возможности.", {money:80000})
  ]),
  ev("Друзья зовут в поездку","Компания собирается в небольшое путешествие. Это дорого, но может дать впечатления.","друзья",[
   ch("Поехать",5,{happiness:20,friend:2,charisma:6}, "Поездка стала ярким воспоминанием.", {money:30000}),
   ch("Остаться и работать",4,{money:rand(15000,55000),discipline:5},"Ты решил укрепить финансы."),
   ch("Предложить бюджетный вариант",3,{happiness:10,friend:1,charisma:8},"Все оценили твою идею."),
  ])
 );
 if(A>=18) pool.push(
  ev("Карьера и деньги","Ты думаешь, как строить финансовое будущее: работа, фриланс, бизнес или инвестиции.","деньги",[
   ch("Найти новую работу",4,{flag:"job_search",discipline:4},"Ты открыл список вакансий."),
   ch("Взять фриланс-заказ",5,{money:rand(20000,120000),mind:6,stress:4},"Фриланс принёс доход и опыт."),
   ch("Начать маленький бизнес",6,{business:1,businessReputation:10,businessName:"Малый бизнес"},"Ты запустил своё дело.",{money:180000}),
   ch("Купить акции",2,{shares:100000},"Ты вложился в акции.",{money:100000})
  ]),
  ev("Семейный разговор","Родные хотят больше внимания. Можно поддержать их или сосредоточиться на себе.","семья",[
   ch("Помочь семье",3,{parents:8,happiness:6,karma:4},"Семья почувствовала поддержку."),
   ch("Отправить деньги",1,{parents:10,karma:6},"Ты помог финансово.",{money:30000}),
   ch("Сказать, что занят",0,{parents:-5,stress:-2},"Ты сохранил время, но родные расстроились."),
   ch("Собрать семейный ужин",4,{parents:12,happiness:12,charisma:3},"Тёплый вечер сблизил семью.",{money:8000})
  ]),
  ev("Личная жизнь","Этот месяц можно посвятить отношениям, знакомствам или семье.","отношения",[
   ch("Искать любовь",3,{partner:1,charisma:8,happiness:6},"Ты встретил интересного человека."),
   ch("Устроить свидание",3,{love:15,happiness:10},"Свидание укрепило отношения.",{money:8000, needRel:true}),
   ch("Поговорить по душам",2,{love:12,mental:6},"Разговор помог понять друг друга."),
   ch("Попросить ребёнка",4,{child:1,happiness:20,stress:5},"В семье появился ребёнок.",{money:60000, needMarriage:true})
  ])
 );
 if(A>=26&&A<=59) pool.push(
  ev("Середина пути","Ты начинаешь оценивать свои достижения: деньги, семья, здоровье, смысл.","взрослая жизнь",[
   ch("Сделать карьерный рывок",6,{career:15,discipline:10,stress:7},"Ты вложился в карьеру."),
   ch("Провести месяц с семьёй",4,{happiness:18,love:8,parents:5,mental:8},"Семейное время восстановило силы."),
   ch("Инвестировать в здоровье",4,{health:18,mental:8,badHabits:-2},"Ты занялся здоровьем.",{money:25000}),
   ch("Развивать бизнес",6,{business:1,businessReputation:15,stress:5},"Бизнес стал сильнее.",{money:250000})
  ]),
  ev("Репутация","О тебе начали говорить. Это шанс усилить личный бренд или остаться в тени.","слава",[
   ch("Выступить публично",5,{fame:35,charisma:14,stress:4},"Публичность принесла известность."),
   ch("Дать интервью",4,{fame:25,charisma:8,money:rand(10000,80000)},"Интервью заметили."),
   ch("Избежать внимания",1,{mental:8,stress:-5},"Ты выбрал спокойствие."),
  ])
 );
 if(A>=60) pool.push(
  ev("Поздние годы","Возраст напоминает о себе. Важнее становится здоровье, семья и наследие.","старость",[
   ch("Заняться здоровьем",4,{health:18,mental:8},"Ты поддержал организм.",{money:30000}),
   ch("Провести время с детьми",3,{happiness:18,karma:8},"Семейные разговоры стали ценными."),
   ch("Написать мемуары",5,{fame:20,creativity:12,mental:8},"Ты оставил историю своей жизни."),
   ch("Искать бессмертие",7,{flag:"immortality_search",mind:20,fame:10},"Ты приблизился к главной цели.")
  ])
 );
 if(game.job) pool.push(
  ev("Рабочий месяц",`Работа «${game.job.name}» требует внимания. Можно выполнить обычные задачи или попытаться выделиться.`,"работа",[
   ch("Работать спокойно",3,{career:4,money:Math.round(calcSalary()/4),discipline:3},"Рабочая рутина принесла стабильность."),
   ch("Взять сложный проект",6,{career:12,mind:8,stress:8,fame:4},"Сложный проект заметили."),
   ch("Попросить повышение",4,{career:8,charisma:7},"Ты поднял вопрос о повышении."),
   ch("Отдохнуть от работы",0,{stress:-8,mental:8,career:-2},"Ты снизил нагрузку.")
  ])
 );
 if(game.relationship==="В отношениях" || game.relationship==="Брак") pool.push(
  ev("Отношения требуют внимания",`Сейчас у тебя ${game.relationship.toLowerCase()} с ${game.partner||"партнёром"}. Нужно поддерживать связь.`,"отношения",[
   ch("Сделать сюрприз",3,{love:16,happiness:10},"Сюрприз удался.",{money:10000}),
   ch("Обсудить будущее",2,{love:10,mental:4},"Разговор стал важным."),
   ch("Провести выходные вместе",4,{love:18,happiness:14,stress:-3},"Вы стали ближе.",{money:15000}),
   ch("Сфокусироваться на себе",1,{mind:6,love:-5},"Ты занялся собой, но партнёр почувствовал дистанцию.")
  ])
 );
 if(game.children.length) pool.push(
  ev("Дети и воспитание",`У тебя детей: ${game.children.length}. Им нужно внимание, деньги и участие.`,"дети",[
   ch("Поиграть с детьми",3,{happiness:14,mental:6,karma:5},"Дети были счастливы."),
   ch("Оплатить развитие",2,{mind:6,karma:8},"Ты вложился в их будущее.",{money:25000*game.children.length}),
   ch("Поговорить по душам",2,{happiness:8,mental:8},"В семье стало теплее."),
   ch("Нанять няню",1,{stress:-8},"Ты разгрузил расписание.",{money:20000*game.children.length})
  ])
 );
 if(game.immortal) pool.push(
  ev("Бессмертная жизнь","Ты победил старение. Теперь вопрос не в выживании, а в смысле бесконечной жизни.","бессмертие",[
   ch("Строить империю",7,{business:2,fame:30,money:rand(100000,500000)},"Ты расширил влияние."),
   ch("Помогать людям",5,{karma:30,fame:20,happiness:12},"Ты стал легендой благотворительности."),
   ch("Изучать науку",6,{mind:35,creativity:10},"Ты углубился в знания."),
   ch("Наслаждаться вечностью",3,{happiness:20,mental:10},"Ты позволил себе жить.")
  ])
 );
 pool = pool.concat(common);
 return choice(pool);
}
function ev(title,text,type,choices){return{title,text,type,choices}}
function ch(text,cost,effects,result,extra={}){return{text,cost,effects,result,money:extra.money||0,need:extra.need||null,hint:extra.hint||"",extra}}
function openCategory(cat){
 let title={life:"Жизнь",study:"Учёба",work:"Работа",people:"Люди",shop:"Имущество"}[cat]||"Действия";
 let actions=[];
 if(cat==="life")actions=[
  ch("Отдохнуть и восстановиться",0,{energy:6,happiness:6,stress:-6,mental:5},"Ты восстановил силы."),
  ch("Заняться спортом",3,{health:10,discipline:4,looks:3,stress:-2},"Спорт пошёл на пользу."),
  ch("Хобби и творчество",3,{creativity:10,happiness:8,mental:4},"Хобби вдохновило тебя."),
  ch("Путешествие",5,{happiness:18,charisma:5,fame:2},"Путешествие расширило кругозор.",{money:60000}),
  ch("Переехать",6,{city:choice(["столица","морской город","тихий район","новый город"]),happiness:5},"Ты переехал.",{money:150000}),
 ];
 if(cat==="study")actions=[
  ch("Самообразование",4,{mind:16,discipline:4},"Ты изучал новое."),
  ch("Курсы навыков",5,{mind:25,discipline:8},"Курсы дали результат.",{money:35000}),
  ch("Творческий курс",4,{creativity:25,charisma:4},"Ты развил творческие навыки.",{money:30000}),
  ch("Медицина",6,{education:"Медицина",mind:35,discipline:8},"Ты начал путь в медицину.",{money:100000,need:{age:18}}),
  ch("Юриспруденция",6,{education:"Юриспруденция",mind:30,charisma:10},"Ты изучал право.",{money:90000,need:{age:18}}),
  ch("Научная программа",6,{education:"Наука",mind:45,creativity:8},"Ты занялся наукой.",{money:120000,need:{age:18}}),
 ];
 if(cat==="work")actions = [
  ...JOBS.map(j=>ch(`Устроиться: ${j.name}`,3,{job:j.id},`Ты устроился на работу: ${j.name}.`,{need:j.need,hint:j.desc})),
  ch("Фриланс-заказ",5,{money:rand(20000,140000),mind:8,stress:5},"Фриланс принёс доход и опыт.",{need:{age:16}}),
  ch("Уволиться",0,{job:null,stress:-5,happiness:3},"Ты ушёл с работы."),
 ];
 if(cat==="people")actions=[
  ch("Встретиться с друзьями",3,{friend:1,happiness:12,charisma:4,stress:-4},"Встреча с друзьями прошла отлично."),
  ch("Позвонить родителям",1,{parents:6,happiness:5,karma:3},"Родители были рады звонку."),
  ch("Помочь семье деньгами",1,{parents:10,karma:8},"Ты помог семье.",{money:30000}),
  ch("Искать отношения",3,{partner:1,charisma:8,happiness:8},"Ты познакомился с интересным человеком.",{need:{age:14}}),
  ch("Сделать предложение",3,{relationship:"Брак",love:20,happiness:20},"Вы поженились.",{money:120000,need:{age:18}}),
  ch("Завести ребёнка",4,{child:1,happiness:20,stress:5},"В семье появился ребёнок.",{money:60000,need:{age:18}}),
 ];
 if(cat==="shop")actions=[
  ...PROPERTIES.map(p=>ch(`Купить: ${p.name}`,2,{home:p.id},`Ты купил жильё: ${p.name}.`,{money:p.price})),
  ...CARS.map(c=>ch(`Купить: ${c.name}`,2,{car:c.id,fame:c.fame},`Ты купил транспорт: ${c.name}.`,{money:c.price})),
  ch("Вложить в акции",2,{shares:100000},"Ты купил акции.",{money:100000}),
  ch("Вложить в крипту",2,{crypto:100000},"Ты купил криптовалюту.",{money:100000}),
  ch("Купить таблетку бессмертия",8,{immortal:true,health:100,mental:100,happiness:100,fame:100},"Ты стал бессмертным.",{money:10000000,need:{age:45,mind:1000,fame:700,business:5}}),
 ];
 showActionModal(title, actions);
}
function showActionModal(title, actions){
 modalCard.innerHTML=`<h2>${title}</h2><div class="modal-line"></div><div class="graves">${actions.map((a,i)=>`<button class="row-card" onclick="modalAction(${i})">${a.text}<br><span style="color:#64748b;font-size:12px">${costText(a)}</span></button>`).join("")}</div><div class="modal-actions"><button class="big-btn btn-blue" onclick="closeModal()">Закрыть</button></div>`;
 window._actions=actions; modalRoot.classList.remove("hidden");
}
function modalAction(i){let a=window._actions[i]; if(!a)return; if(!canChoose(a)){toast("Не хватает энергии, денег или условий");return} closeModal(); if(a.cost)game.energy-=a.cost;if(a.money)game.money-=a.money;let res=applyEffects(a.effects||{},a.result||"Действие выполнено.");log("Действие",`${a.text}: ${res}`);game.lastResult=res;checkDeath();renderGame();}
function checkLimits(){["health","happiness","mental","looks"].forEach(k=>game[k]=clamp(game[k])); game.energy=clamp(game.energy,0,game.monthlyEnergy); game.stress=clamp(game.stress||0); ["money","mind","charisma","creativity","discipline","fame","parents","love","friends","business","businessReputation","criminal","karma"].forEach(k=>{if(typeof game[k]==="number")game[k]=Math.round(game[k])}); if(game.relationship==="Одинок" && game.partner)game.relationship="В отношениях"; if(game.relationship==="Брак" && !game.partner)game.partner=choice(["Алекс","Саша","Марина","Оля","Ира","Никита","Максим","Катя","Лена","Дима"]); if(game.job && typeof game.job==="string") game.job=JOBS.find(j=>j.id===game.job); if(game.home && typeof game.home==="string") game.home=PROPERTIES.find(p=>p.id===game.home); if(game.car && typeof game.car==="string") game.car=CARS.find(c=>c.id===game.car);}
function checkDeath(){if(!game||game.immortal)return;if(game.health<=0)die("Здоровье упало до нуля.");else if(game.mental<=0)die("Психика не выдержала жизненного давления.");else if(game.age>=80&&rand(1,100)<=Math.min(70,(game.age-79)*5))die("Смерть от старости.");}
function ending(){
 if(game.immortal)return"Бессмертная легенда";
 if(game.money>=10000000&&game.business>=5)return"Легендарный магнат";
 if(game.fame>=1000)return"Мировая знаменитость";
 if(game.children.length>=3&&game.happiness>=70)return"Глава большой семьи";
 if(game.mind>=1500)return"Гений своего поколения";
 if(game.business>=7)return"Империя бизнеса";
 if(game.criminal>=50)return"Криминальная судьба";
 if(game.debt>game.money+500000)return"Жизнь в долгах";
 if(game.friends<=1&&game.relationship==="Одинок")return"Одинокий путь";
 if(game.happiness>=80)return"Счастливая жизнь";
 return"Обычная, но уникальная жизнь";
}
function die(reason){game.game_over=true;game.death_reason=reason;game.ending=ending();let l=loadJSON(GRAVES,[]);l.push({name:game.name,age:game.age,months:game.totalMonths,money:game.money,level:game.level,reason,ending:game.ending,children:game.children.length,business:game.business,country:game.country,journal:game.journal.slice(0,20)});saveJSON(GRAVES,l);showModal("Жизнь завершена",`${reason}\n\nКонцовка: ${game.ending}\n\nВозраст: ${game.age}\nДеньги: ${money(game.money)}\nДети: ${game.children.length}\nБизнес: ${game.business}`,[{text:"Новая игра",cls:"btn-green",fn:()=>{closeModal();showNewGame()}},{text:"Главное меню",cls:"btn-blue",fn:()=>{closeModal();renderMenu()}}]);}
function checkAchievements(){let l=[["Первые деньги",game.money>=1000],["Школьник",game.age>=7],["Взрослая жизнь",game.age>=18],["Умный человек",game.mind>=300],["Известный человек",game.fame>=300],["Семьянин",game.children.length>=1],["Бизнесмен",game.business>=1],["Миллионер",game.money>=1000000],["Бессмертный",game.immortal],["Большая семья",game.children.length>=3],["Легенда",game.fame>=1000]];game.achievements||=[];l.forEach(([n,o])=>{if(o&&!game.achievements.includes(n)){game.achievements.push(n);log("Достижение",n)}})}
function showModal(t,txt,btns=[{text:"Закрыть",cls:"btn-blue",fn:closeModal}]){modalCard.innerHTML=`<h2>${t}</h2><div class="modal-line"></div><div class="modal-text">${txt}</div><div class="modal-actions">${btns.map((b,i)=>`<button class="big-btn ${b.cls||'btn-blue'}" onclick="modalButton(${i})">${b.text}</button>`).join("")}</div>`;window._modalButtons=btns;modalRoot.classList.remove("hidden")}
function modalButton(i){let b=window._modalButtons[i];if(b&&b.fn)b.fn()}function closeModal(){modalRoot.classList.add("hidden")}
function showNewGame(){modalCard.innerHTML=`<h2>Создать новую жизнь</h2><div class="modal-line"></div><input class="input" id="nameInput" placeholder="Имя персонажа" value="Zeus"/><div class="modal-actions"><button class="big-btn btn-blue" onclick="startGender('Мужской')">Мужской</button><button class="big-btn btn-red" onclick="startGender('Женский')">Женский</button><button class="big-btn btn-purple" onclick="startGender('Случайно')">Случайно</button><button class="big-btn btn-gray" onclick="closeModal()">Отмена</button></div>`;modalRoot.classList.remove("hidden")}
function startGender(g){let n=$("#nameInput").value.trim();closeModal();newGame(n,g==="Случайно"?choice(["Мужской","Женский"]):g)}
function showDiary(){if(!game)return;let html=game.journal.length?game.journal.slice(0,40).map(j=>`• ${j.age} лет: ${j.title}\n${j.text}`).join("\n\n"):"Пока записей нет.";showModal("Дневник",html)}
function showGoals(){showModal("Цели",`Главная цель: купить таблетку бессмертия.\n\nНужно: 45+ лет, ум 1000+, известность 700+, бизнес 5+, 10 000 000 ₽.\n\nДополнительные цели:\n• построить семью\n• стать знаменитым\n• создать бизнес\n• стать миллионером\n• оставить след в истории`)}
function showStats(){if(!game)return;showModal("Статы",`Имя: ${game.name}\nВозраст: ${game.age}\nМесяц: ${MONTHS[game.month]}\nДеньги: ${money(game.money)}\nУровень: ${game.level}\nУм: ${game.mind}\nХаризма: ${game.charisma}\nТворчество: ${game.creativity}\nДисциплина: ${game.discipline}\nДрузья: ${game.friends}\nРабота: ${game.job?game.job.name:"Нет"}\nОтношения: ${game.relationship} ${game.partner?game.partner:""}\nДети: ${game.children.length}\nБизнес: ${game.business}\nЖильё: ${game.home?game.home.name:"Нет"}\nТранспорт: ${game.car?game.car.name:"Нет"}\nСтресс: ${game.stress}\nДолг: ${money(game.debt)}`)}
function showAssets(){if(!game)return;showModal("Активы и имущество",`Жильё: ${game.home?game.home.name:"Нет"}\nТранспорт: ${game.car?game.car.name:"Нет"}\nБизнес: ${game.business} уровень\nАкции: ${money(game.shares)}\nКрипта: ${money(game.crypto)}\nДолг: ${money(game.debt)}\n\nОткрой «Имущество» в быстрых действиях, чтобы покупать дом, транспорт и инвестиции.`)}
function showGraves(){let l=loadJSON(GRAVES,[]);let html=l.length?l.slice().reverse().map((g,i)=>`<button class="row-card" onclick="graveInfo(${l.length-1-i})">🪦 ${g.name}, ${g.age} лет — ${g.ending}</button>`).join(""):`<div class="row-card">Пока прошлых жизней нет.</div>`;modalCard.innerHTML=`<h2>Ваши игры</h2><div class="modal-line"></div><div class="graves">${html}</div><div class="modal-actions"><button class="big-btn btn-blue" onclick="closeModal()">Закрыть</button></div>`;modalRoot.classList.remove("hidden")}
function graveInfo(i){let g=loadJSON(GRAVES,[])[i];showModal("Статистика жизни",`Имя: ${g.name}\nВозраст: ${g.age} лет\nДеньги: ${money(g.money)}\nКонцовка: ${g.ending}\nДети: ${g.children}\nБизнес: ${g.business}\nПричина: ${g.reason}`)}
function showSettings(){let row=(k,t,s)=>`<div class="row-card setting-row" onclick="toggleSetting('${k}')"><div><b>${t}</b><span>${s}</span></div><div class="switch ${settings[k]?'on':''}"></div></div>`;modalCard.innerHTML=`<h2>Настройки</h2><div class="modal-line"></div><div class="settings">${row("music","Фоновая музыка","Музыка в меню и игре")}${row("sound","Звук","Эффекты действий")}${row("vibration","Вибрация","Отклик при нажатиях")}${row("autosave","Автосохранение","Сохранять после действий")}${row("cloud","Синхронизация","Заготовка под облако")}${row("google","Google Play Игры","Заготовка под достижения")}</div><div class="modal-actions"><button class="big-btn btn-blue" onclick="closeModal()">Закрыть</button></div>`;modalRoot.classList.remove("hidden")}
function toggleSetting(k){settings[k]=!settings[k];saveJSON(SETTINGS,settings);applyMusic();showSettings()}function tryExit(){showModal("Выход","Закрой приложение кнопкой телефона или сверни его.")}
window.NativeBack=function(){if(!modalRoot.classList.contains("hidden"))closeModal();else renderMenu()}
renderMenu();




/* ==========================================================
   v14 RELOAD PLUS EXTENSION
   Больше систем: питание, спорт, курсы, хобби, фриланс,
   банк/кредиты, путешествия, питомцы, инвентарь, одежда,
   жильё, транспорт, кладбище, взрослые события и годовой итог.
   ========================================================== */

const V14_SKILLS = [
  "Программирование","Дизайн","Общепит","Ритейл","Продажи","Английский","Фотография","Блоггинг",
  "Медицина","Косметология","Экономика","Полиция","Музыка","Актёрское искусство","Вождение",
  "Журналистика","Кулинария","Финансовая грамотность","3D-моделирование","Видеомонтаж"
];

const V14_ITEMS = [
  {id:"book_prog",name:"Книга по программированию",price:3000,skill:"Программирование",mind:8},
  {id:"book_fin",name:"Книга по финансам",price:3500,skill:"Финансовая грамотность",mind:8},
  {id:"camera",name:"Фотоаппарат",price:45000,skill:"Фотография",creativity:10},
  {id:"tablet",name:"Графический планшет",price:55000,skill:"Дизайн",creativity:12},
  {id:"guitar",name:"Гитара",price:25000,skill:"Музыка",creativity:12},
  {id:"drums",name:"Барабаны",price:70000,skill:"Музыка",creativity:18},
  {id:"easel",name:"Мольберт",price:18000,skill:"Дизайн",creativity:8},
  {id:"bike",name:"Велосипед",price:30000,health:8},
  {id:"yoga_mat",name:"Коврик для йоги",price:6000,health:5,mental:8},
  {id:"skates",name:"Ролики",price:15000,health:6},
  {id:"pc_basic",name:"Простой компьютер",price:65000,skill:"Программирование",mind:15},
  {id:"pc_pro",name:"Мощный компьютер",price:220000,skill:"Видеомонтаж",mind:25,creativity:20},
  {id:"phone_pro",name:"Флагманский телефон",price:120000,fame:8},
  {id:"dating_app",name:"Сервис знакомств",price:12000,charisma:8},
  {id:"music_player",name:"Музыкальный проигрыватель",price:9000,happiness:8},
];

const V14_PETS = [
  ["Кот сфинкс",35000],["Сиамская кошка",25000],["Мейн-кун",60000],["Безродный кот",3000],
  ["Хаски",55000],["Лабрадор",45000],["Доберман",60000],["Корги",70000],["Дворняга",2000],
  ["Мопс",40000],["Пудель",45000],["Ротвейлер",65000]
];

const V14_TRAVEL = [
  ["Москва",45000],["Санкт-Петербург",50000],["Берлин",90000],["Париж",130000],["Рим",120000],
  ["Венеция",150000],["Лондон",160000],["Токио",220000],["Сеул",190000],["Бангкок",140000],
  ["Пхукет",170000],["Бали",210000],["Дубай",180000],["Нью-Йорк",230000],["Лас-Вегас",210000],
  ["Гавайи",320000],["Рио-де-Жанейро",190000],["Стамбул",110000],["Прага",95000],["Сингапур",240000]
];

const V14_BUSINESSES = [
  {id:"gamedev",name:"Студия разработки игр",price:450000,skill:"Программирование"},
  {id:"photo",name:"Фотостудия",price:280000,skill:"Фотография"},
  {id:"coffee",name:"Городская кофейня",price:350000,skill:"Общепит"},
  {id:"beauty",name:"Студия красоты",price:420000,skill:"Косметология"},
  {id:"clinic",name:"Медицинская клиника",price:1200000,skill:"Медицина"},
  {id:"english",name:"Онлайн-школа английского",price:500000,skill:"Английский"},
  {id:"security",name:"Охранное агентство",price:650000,skill:"Полиция"},
  {id:"restaurant",name:"Ресторан",price:950000,skill:"Кулинария"},
  {id:"eshop",name:"Интернет-магазин",price:300000,skill:"Продажи"},
  {id:"theater",name:"Театр",price:1500000,skill:"Актёрское искусство"},
  {id:"delivery",name:"Служба доставки",price:500000,skill:"Вождение"},
  {id:"news",name:"Новостной портал",price:550000,skill:"Журналистика"},
  {id:"musicshop",name:"Магазин музыкальных товаров",price:450000,skill:"Музыка"}
];

const V14_FREELANCE = [
  ["Няня",12000,"Харизма"],["Доставщик еды",18000,"Вождение"],["Грузчик",22000,"Сила"],
  ["Разработка сайта",80000,"Программирование"],["Разработка приложения",150000,"Программирование"],
  ["Дизайн интерфейса",70000,"Дизайн"],["Отрисовка изображения",30000,"Дизайн"],
  ["Перевод текста",25000,"Английский"],["Фотосессия",40000,"Фотография"],["Продажа фотографий",15000,"Фотография"],
  ["Копирайтинг",25000,"Журналистика"],["Блог",0,"Блоггинг"],["Музыка на корпоративе",60000,"Музыка"],
  ["Такси",35000,"Вождение"],["Аниматор",30000,"Актёрское искусство"],["Съёмки в рекламе",90000,"Актёрское искусство"],
  ["Торты на заказ",40000,"Кулинария"],["3D-модель",80000,"3D-моделирование"],["Монтаж видео",60000,"Видеомонтаж"]
];

const V14_GRAVES = ["Деревянный крест","Каменный крест","Каменное надгробье","Спящий ангел","Скорбящий ангел","Мраморное надгробье","Монумент","Кельтский крест","Бюст","Плачущий ангел"];

function ensureV14(){
 if(!game) return;
 game.version = 14;
 game.actionMode = "month-energy";
 game.inventory = game.inventory || [];
 game.skills = game.skills || {};
 V14_SKILLS.forEach(s=>{ if(game.skills[s]===undefined) game.skills[s]=0; });
 game.pets = game.pets || [];
 game.clothes = game.clothes || "Обычная одежда";
 game.foodPlan = game.foodPlan || "Домашнее питание";
 game.sportPlan = game.sportPlan || "Нет";
 game.rent = game.rent || null;
 game.bank = game.bank || {loans:[],creditScore:50};
 game.travelHistory = game.travelHistory || [];
 game.graveType = game.graveType || "Каменное надгробье";
 game.graveArea = game.graveArea || 1;
 game.lifeFeeling = game.lifeFeeling ?? game.happiness ?? 70;
 game.actionsSpent = game.actionsSpent || 0;
 game.yearSummary = game.yearSummary || [];
 game.acquaintances = game.acquaintances || 0;
 game.relatives = game.relatives || {mother:true,father:true,grandchildren:0,inlaws:false};
}

const oldNewGame = newGame;
newGame = function(name="",gender="Мужской"){
 oldNewGame(name, gender);
 ensureV14();
 game.monthlyEnergy = 20;
 game.energy = 20;
 game.lifeFeeling = game.happiness;
 game.inventory = [];
 game.skills = {};
 V14_SKILLS.forEach(s=>game.skills[s]=0);
 game.pets = [];
 game.bank = {loans:[],creditScore:50};
 game.travelHistory = [];
 game.graveType = "Каменное надгробье";
 game.graveArea = 1;
 log("Новая система", "Включён режим v14: 20 действий/энергии в месяц, расширенные разделы, фриланс, бизнес, банк, питомцы, путешествия и инвентарь.");
 saveGame();
}

const oldRenderGame = renderGame;
renderGame = function(){
 ensureV14();
 oldRenderGame();
}

const oldApplyEffects = applyEffects;
applyEffects = function(e, result){
 ensureV14();
 for(const [k,v] of Object.entries(e||{})){
   if(k==="skill"){
     game.skills[v[0]] = (game.skills[v[0]]||0) + v[1];
   }
   if(k==="inventory"){
     if(!game.inventory.includes(v)) game.inventory.push(v);
   }
   if(k==="pet"){
     game.pets.push(v);
   }
   if(k==="lifeFeeling"){
     game.lifeFeeling += v;
     game.happiness += Math.round(v/2);
   }
   if(k==="acquaintances"){
     game.acquaintances += v;
   }
 }
 return oldApplyEffects(e, result);
}

function v14Skill(name){ ensureV14(); return game.skills[name]||0; }
function v14HasItem(id){ ensureV14(); return game.inventory.includes(id); }
function v14AddSkill(name, n){ ensureV14(); game.skills[name]=(game.skills[name]||0)+n; game.mind += Math.max(0, Math.floor(n/3)); }
function v14CostOK(cost){ return game.money >= cost; }

function actionCard(text, cost, effects, result, extra={}){
 return ch(text, cost, effects, result, extra);
}

const oldOpenCategory = openCategory;
openCategory = function(cat){
 ensureV14();
 if(cat==="life") return showV14Life();
 if(cat==="study") return showV14Study();
 if(cat==="work") return showV14Work();
 if(cat==="people") return showV14People();
 if(cat==="shop") return showV14Shop();
 return oldOpenCategory(cat);
}

function showV14Life(){
 let actions = [
  actionCard("Отдохнуть дома",0,{energy:7,lifeFeeling:4,stress:-8,mental:7},"Ты восстановил силы."),
  actionCard("Погулять по городу",2,{lifeFeeling:7,charisma:2,stress:-4},"Прогулка помогла разгрузить голову."),
  actionCard("Сходить в кино",2,{lifeFeeling:8,happiness:6},"Фильм дал новые эмоции.",{money:1500}),
  actionCard("Концерт или театр",3,{lifeFeeling:12,creativity:4,fame:1},"Культурный вечер запомнился.",{money:7000}),
  actionCard("Аквапарк / парк развлечений",4,{lifeFeeling:15,happiness:12,health:-1},"Ты отлично провёл время.",{money:12000}),
  actionCard("Путешествовать",5,{lifeFeeling:20,charisma:6,stress:-8},"Путешествие обновило жизнь.",{money:60000}),
  actionCard("Переехать в другой город",6,{city:choice(["столица","морской город","новый город","тихий район"]),lifeFeeling:8,acquaintances:2},"Переезд открыл новую главу.",{money:120000}),
 ];
 showActionModal("Жизнь и досуг", actions);
}

function showV14Study(){
 let actions = [
  actionCard("Самообучение",3,{mind:14,discipline:4,lifeFeeling:2},"Ты занимался самообучением."),
  actionCard("Курсы программирования",5,{skill:["Программирование",25],mind:10},"Ты изучал программирование.",{money:35000}),
  actionCard("Курсы дизайна",5,{skill:["Дизайн",25],creativity:10},"Ты прокачал дизайн.",{money:30000}),
  actionCard("Курсы английского",4,{skill:["Английский",25],charisma:4},"Английский стал лучше.",{money:25000}),
  actionCard("Фотография",4,{skill:["Фотография",20],creativity:8},"Ты учился фотографии.",{money:20000}),
  actionCard("Блоггинг",4,{skill:["Блоггинг",25],charisma:8,fame:4},"Ты изучал блогинг.",{money:18000}),
  actionCard("Финансовая грамотность",4,{skill:["Финансовая грамотность",25],mind:8},"Ты разобрался с финансами.",{money:22000}),
  actionCard("Видеомонтаж",5,{skill:["Видеомонтаж",25],creativity:8},"Ты учился монтажу.",{money:30000}),
  actionCard("3D-моделирование",5,{skill:["3D-моделирование",25],creativity:10},"Ты прокачал 3D.",{money:40000}),
  actionCard("Высшее образование: медицина",7,{education:"Медицина",skill:["Медицина",40],mind:25,discipline:10},"Ты поступил на медицину.",{money:120000,need:{age:18}}),
  actionCard("Высшее образование: право",7,{education:"Юриспруденция",skill:["Журналистика",10],mind:25,charisma:12},"Ты начал изучать право.",{money:110000,need:{age:18}}),
 ];
 showActionModal("Учёба, курсы и навыки", actions);
}

function showV14Work(){
 let actions = [];
 actions.push(actionCard("Посмотреть вакансии",1,{discipline:1},"Ты изучил рынок вакансий."));
 JOBS.forEach(j=>{
   actions.push(actionCard("Устроиться: "+j.name,3,{job:j.id},`Ты устроился на работу: ${j.name}.`,{need:j.need,hint:`ЗП ${money(j.salary)}, энергия/мес ${j.energy}. ${j.desc}`}));
 });
 actions.push(actionCard("Уволиться",0,{job:null,stress:-8,lifeFeeling:2},"Ты уволился."));
 actions.push(actionCard("Попросить повышение",3,{career:10,charisma:5,stress:3},"Ты попытался договориться о повышении."));
 actions.push(actionCard("Сменить сферу карьеры",4,{job:null,career:-5,lifeFeeling:6},"Ты решил изменить профессиональный путь."));
 V14_FREELANCE.forEach(f=>{
   let income = f[0]==="Блог" ? Math.max(5000, game.fame*rand(250,900)+v14Skill("Блоггинг")*600) : f[1] + v14Skill(f[2])*rand(100,500);
   actions.push(actionCard("Фриланс: "+f[0],4,{money:income,skill:[f[2],8],stress:3,lifeFeeling:2},`Фриланс «${f[0]}» принёс ${money(income)}.`,{need:{age:14}}));
 });
 showActionModal("Работа, карьера и фриланс", actions);
}

function showV14People(){
 let actions=[
  actionCard("Познакомиться с людьми",2,{acquaintances:rand(1,4),charisma:5,lifeFeeling:5},"Ты расширил круг общения."),
  actionCard("Встретиться с друзьями",3,{friend:1,lifeFeeling:10,charisma:4,stress:-5},"Встреча с друзьями прошла тепло."),
  actionCard("Попросить помощи у друзей",1,{money:rand(2000,25000),friend:-1},"Друзья помогли, но отношения стали чуть слабее."),
  actionCard("Позвонить родителям",1,{parents:7,lifeFeeling:5,karma:3},"Родители были рады."),
  actionCard("Помочь семье деньгами",1,{parents:12,karma:8,lifeFeeling:4},"Ты помог семье.",{money:30000}),
  actionCard("Семейный ужин",3,{parents:10,lifeFeeling:10,charisma:3},"Семья стала ближе.",{money:10000}),
  actionCard("Искать отношения",3,{partner:1,charisma:8,lifeFeeling:8},"Ты встретил интересного человека.",{need:{age:14}}),
  actionCard("Свидание",3,{love:18,lifeFeeling:12,charisma:4},"Свидание прошло хорошо.",{money:8000}),
  actionCard("Подарить подарок партнёру",2,{love:12,lifeFeeling:5},"Подарок порадовал партнёра.",{money:15000}),
  actionCard("Сделать предложение",3,{relationship:"Брак",love:25,lifeFeeling:20},"Вы поженились.",{money:120000,need:{age:18}}),
  actionCard("Завести ребёнка",4,{child:1,lifeFeeling:20,stress:5},"В семье появился ребёнок.",{money:60000,need:{age:18}}),
  actionCard("Воспитывать детей",3,{lifeFeeling:12,karma:8,stress:-2},"Ты уделил время детям."),
  actionCard("Развестись",2,{relationship:"Одинок",love:-50,lifeFeeling:-15,stress:10},"Отношения закончились."),
 ];
 V14_PETS.forEach(p=>{
   actions.push(actionCard("Купить питомца: "+p[0],2,{pet:p[0],lifeFeeling:12,stress:-5},`Теперь у тебя есть питомец: ${p[0]}.`,{money:p[1],need:{age:10}}));
 });
 showActionModal("Друзья, семья, отношения и питомцы", actions);
}

function showV14Shop(){
 let actions=[];
 actions.push(actionCard("Питание: беспорядочное",0,{foodPlan:"Беспорядочное питание",health:-4,lifeFeeling:2},"Ты стал питаться как попало."));
 actions.push(actionCard("Питание: домашнее",1,{foodPlan:"Домашнее питание",health:4,lifeFeeling:3},"Домашнее питание поддерживает здоровье.",{money:5000}));
 actions.push(actionCard("Питание: индивидуальная диета",2,{foodPlan:"Диета",health:10,looks:3},"Диета улучшила самочувствие.",{money:20000}));
 actions.push(actionCard("Спорт: йога",2,{sportPlan:"Йога",health:6,mental:10,stress:-7},"Йога помогла психике.",{money:4000}));
 actions.push(actionCard("Спорт: тренажёрный зал",3,{sportPlan:"Зал",health:12,looks:7,discipline:4},"Тренировки дали результат.",{money:12000}));
 actions.push(actionCard("Одежда: статусная",1,{clothes:"Статусная одежда",looks:8,fame:4,lifeFeeling:4},"Ты обновил гардероб.",{money:60000}));
 PROPERTIES.forEach(p=>actions.push(actionCard("Купить жильё: "+p.name,2,{home:p.id,lifeFeeling:p.happiness},`Ты купил жильё: ${p.name}.`,{money:p.price})));
 actions.push(actionCard("Арендовать комнату",1,{rent:"Комната",lifeFeeling:2},"Ты снял комнату.",{money:20000,need:{age:18}}));
 actions.push(actionCard("Арендовать квартиру",1,{rent:"Квартира",lifeFeeling:5},"Ты снял квартиру.",{money:70000,need:{age:18}}));
 CARS.forEach(c=>actions.push(actionCard("Купить транспорт: "+c.name,2,{car:c.id,fame:c.fame,lifeFeeling:4},`Ты купил транспорт: ${c.name}.`,{money:c.price})));
 V14_ITEMS.forEach(it=>{
   let eff={inventory:it.id,lifeFeeling:2};
   if(it.skill) eff.skill=[it.skill,12];
   if(it.mind) eff.mind=it.mind;
   if(it.creativity) eff.creativity=it.creativity;
   if(it.health) eff.health=it.health;
   if(it.mental) eff.mental=it.mental;
   if(it.fame) eff.fame=it.fame;
   if(it.happiness) eff.happiness=it.happiness;
   actions.push(actionCard("Купить предмет: "+it.name,1,eff,`Куплен предмет: ${it.name}.`,{money:it.price}));
 });
 actions.push(actionCard("Вложить в валюту",1,{shares:50000},"Ты купил валюту.",{money:50000}));
 actions.push(actionCard("Вложить в золото",1,{shares:100000},"Ты купил золото.",{money:100000}));
 actions.push(actionCard("Криптовалюта",2,{crypto:100000},"Ты вложился в крипту.",{money:100000}));
 actions.push(actionCard("Взять кредит 500 000 ₽",0,{money:500000,debt:650000},"Банк выдал кредит.",{need:{age:18}}));
 actions.push(actionCard("Погасить часть кредита",1,{debt:-100000},"Ты погасил часть кредита.",{money:100000}));
 actions.push(actionCard("Таблетка бессмертия",8,{immortal:true,health:100,mental:100,lifeFeeling:100,fame:120},"Ты стал бессмертным.",{money:10000000,need:{age:45,mind:1000,fame:700,business:5}}));
 showActionModal("Питание, спорт, магазин, банк и имущество", actions);
}

function showV14Business(){
 let actions=[];
 V14_BUSINESSES.forEach(b=>{
   actions.push(actionCard("Открыть: "+b.name,6,{business:1,businessReputation:10,businessName:b.name,skill:[b.skill,8]},`Ты открыл бизнес: ${b.name}.`,{money:b.price,need:{age:18}}));
 });
 actions.push(actionCard("Улучшить бизнес",5,{business:1,businessReputation:20,stress:5},"Бизнес вырос на уровень.",{money:250000,need:{age:18}}));
 actions.push(actionCard("Нанять менеджера",3,{businessReputation:15,stress:-8},"Менеджер взял часть задач.",{money:150000,need:{age:18}}));
 actions.push(actionCard("Продать бизнес",2,{money:game.business*250000,business:-game.business,businessReputation:-game.businessReputation},"Ты продал бизнес."));
 showActionModal("Бизнес", actions);
}

function showV14Travel(){
 let actions=[];
 V14_TRAVEL.forEach(t=>{
   actions.push(actionCard("Поехать: "+t[0],5,{lifeFeeling:18,travelCity:t[0],charisma:4,stress:-8,fame:2},`Путешествие в ${t[0]} запомнилось надолго.`,{money:t[1]}));
 });
 showActionModal("Путешествия", actions);
}

function showActionModal(title, actions){
 ensureV14();
 modalCard.innerHTML=`<h2>${title}</h2><div class="modal-line"></div>
 <div class="badge-row">
  <span class="badge">⚡ ${game.energy}/${game.monthlyEnergy}</span>
  <span class="badge">💰 ${money(game.money)}</span>
  <span class="badge">❤️ ${game.lifeFeeling}/100</span>
 </div>
 <div class="graves">${actions.map((a,i)=>`<button class="row-card" onclick="modalAction(${i})">${a.text}<br><span style="color:#64748b;font-size:12px">${costText(a)}${a.hint? " • "+a.hint:""}</span></button>`).join("")}</div>
 <div class="modal-actions">
  <button class="big-btn btn-purple" onclick="showV14Business()">Бизнес</button>
  <button class="big-btn btn-orange" onclick="showV14Travel()">Путешествия</button>
  <button class="big-btn btn-blue" onclick="closeModal()">Закрыть</button>
 </div>`;
 window._actions=actions; modalRoot.classList.remove("hidden");
}

const oldNextMonth = nextMonth;
nextMonth = function(){
 ensureV14();
 let beforeYear = game.age;
 oldNextMonth();
 ensureV14();
 if(game.lifeFeeling<=0 && !game.game_over){ die("Чувство жизни упало до нуля."); return; }
 if(game.age!==beforeYear) v14YearResult();
}

function v14YearResult(){
 ensureV14();
 let txt=[];
 if(game.age===12) txt.push("С 12 лет открываются спорт, самообучение и более серьёзные хобби.");
 if(game.age===18) txt.push("С 18 лет открываются взрослая работа, банк, бизнес, аренда и отношения.");
 if(game.age===25 && !game.home && !game.rent){
   game.health-=18; game.lifeFeeling-=12; txt.push("После 25 лет нет жилья — ты оказался в тяжёлой ситуации. Здоровье сильно снизилось.");
 }
 if(game.age===65){
   if(game.job){
     let pension = game.jobExp>180 ? 45000 : 18000;
     game.job=null; game.money+=pension;
     txt.push(`Ты вышел на пенсию. Пенсионная выплата: ${money(pension)}.`);
   } else txt.push("Пенсионный возраст. Без большого стажа выплаты минимальные.");
 }
 if(txt.length){log("Годовой итог",txt.join("\n")); game.lastResult=txt.join("\n");}
}

const oldRandomMonthlyEvent = randomMonthlyEvent;
randomMonthlyEvent = function(){
 ensureV14();
 let scripted=[
  ()=>{ if(game.home && rand(1,100)<35){let a=rand(20000,180000);game.money-=Math.min(game.money,a);return`Событие: в жилье случилась поломка. Ремонт стоил ${money(a)}.`} return null; },
  ()=>{ if(game.relationship==="Брак" && rand(1,100)<25){game.love-=rand(10,25);game.lifeFeeling-=8;return"Событие: в браке возник кризис доверия."; } return null; },
  ()=>{ if(game.children.length && rand(1,100)<30){game.lifeFeeling+=10;game.money-=Math.min(game.money,rand(10000,50000));return"Событие: ребёнку понадобилась помощь и внимание."; } return null; },
  ()=>{ if(game.friends>3 && rand(1,100)<30){game.lifeFeeling+=12;game.charisma+=4;return"Событие: друзья устроили неожиданную встречу."; } return null; },
  ()=>{ if(game.job && rand(1,100)<25){game.career-=5;game.stress+=12;return"Событие: проблемы на работе. Руководство недовольно результатами."; } return null; },
  ()=>{ if(game.business>0 && rand(1,100)<25){let a=game.business*rand(30000,160000);game.money+=a;game.businessReputation+=5;return`Событие: бизнес получил крупный заказ на ${money(a)}.`; } return null; },
  ()=>{ if(game.age>45 && rand(1,100)<18){game.disease=choice(["Серьёзное заболевание","Травма","Проблемы с сердцем"]);game.health-=rand(10,25);return`Событие: здоровье подвело — ${game.disease}.`; } return null; },
  ()=>{ if(game.pets.length && rand(1,100)<30){game.lifeFeeling+=8;game.stress-=5;return`Событие: питомец ${choice(game.pets)} поднял настроение.`; } return null; },
  ()=>{ if(game.travelHistory.length && rand(1,100)<22){game.fame+=5;game.lifeFeeling+=5;return"Событие: воспоминания о путешествии вдохновили тебя."; } return null; },
  ()=>{ if(game.debt>500000 && rand(1,100)<28){game.lifeFeeling-=12;game.stress+=15;return"Событие: банк напомнил о долгах. Давление растёт."; } return null; },
 ];
 for(let i=0;i<4;i++){let r=choice(scripted)(); if(r)return r;}
 return oldRandomMonthlyEvent();
}

const oldApplyEffects2 = applyEffects;
applyEffects = function(e,result){
 ensureV14();
 if(e && e.travelCity){ game.travelHistory.push(e.travelCity); delete e.travelCity; }
 let out = oldApplyEffects2(e,result);
 game.lifeFeeling = clamp(game.lifeFeeling ?? game.happiness);
 return out;
}

const oldShowStats = showStats;
showStats = function(){
 ensureV14();
 let topSkills = Object.entries(game.skills).sort((a,b)=>b[1]-a[1]).slice(0,8).map(([k,v])=>`${k}: ${v}`).join("\n");
 showModal("Статы",`Имя: ${game.name}
Возраст: ${game.age}
Месяц: ${MONTHS[game.month]}
Деньги: ${money(game.money)}
Энергия: ${game.energy}/${game.monthlyEnergy}
Здоровье: ${game.health}
Чувство жизни: ${game.lifeFeeling}
Психика: ${game.mental}
Слава: ${game.fame}
Работа: ${game.job?game.job.name:"Нет"}
Образование: ${game.education}
Друзья: ${game.friends}
Знакомые: ${game.acquaintances}
Отношения: ${game.relationship} ${game.partner?game.partner:""}
Дети: ${game.children.length}
Питомцы: ${game.pets.length ? game.pets.join(", ") : "Нет"}
Бизнес: ${game.business} ${game.businessName||""}
Жильё: ${game.home?game.home.name:(game.rent?"Аренда: "+game.rent:"Нет")}
Транспорт: ${game.car?game.car.name:"Нет"}
Питание: ${game.foodPlan}
Спорт: ${game.sportPlan}
Одежда: ${game.clothes}
Долг: ${money(game.debt)}

Лучшие навыки:
${topSkills || "Пока нет"}`);
}

const oldShowAssets = showAssets;
showAssets = function(){
 ensureV14();
 showModal("Активы и инвентарь",`Жильё: ${game.home?game.home.name:(game.rent?"Аренда: "+game.rent:"Нет")}
Транспорт: ${game.car?game.car.name:"Нет"}
Бизнес: ${game.business} ${game.businessName||""}
Акции/золото/валюта: ${money(game.shares)}
Крипта: ${money(game.crypto)}
Долг: ${money(game.debt)}
Питомцы: ${game.pets.length ? game.pets.join(", ") : "Нет"}

Инвентарь:
${game.inventory.length ? game.inventory.map(id=>(V14_ITEMS.find(i=>i.id===id)?.name||id)).join("\n") : "Пусто"}`);
}

const oldShowGoals = showGoals;
showGoals = function(){
 showModal("Цели",`Главная цель: купить таблетку бессмертия.

Нужно: 45+ лет, ум 1000+, известность 700+, бизнес 5+, 10 000 000 ₽.

Большие пути жизни:
• построить карьеру
• создать семью и вырастить детей
• открыть бизнес
• стать знаменитым блогером/актёром
• стать учёным, врачом, юристом или политиком
• купить жильё и транспорт
• путешествовать по миру
• собрать инвентарь и питомцев
• прожить яркую жизнь с высоким чувством жизни`);
}

const oldEnding = ending;
ending = function(){
 ensureV14();
 if(game.immortal)return"Бессмертная легенда";
 if(game.travelHistory.length>=15)return"Гражданин мира";
 if(game.pets.length>=5)return"Доброе сердце";
 if(game.children.length>=4 && game.relatives.grandchildren>0)return"Основатель большой династии";
 if(game.skills && Object.values(game.skills).some(v=>v>=600))return"Мастер своего дела";
 return oldEnding();
}

const oldDie = die;
die = function(reason){
 ensureV14();
 game.graveType = choice(V14_GRAVES);
 oldDie(reason);
}

const oldShowGraves = showGraves;
showGraves = function(){
 let l=loadJSON(GRAVES,[]);
 let html=l.length?l.slice().reverse().map((g,i)=>`<button class="row-card" onclick="graveInfo(${l.length-1-i})">🪦 ${g.name}, ${g.age} лет — ${g.ending}<br><span style="color:#64748b;font-size:12px">могила: ${g.graveType||"Каменное надгробье"}</span></button>`).join(""):`<div class="row-card">Пока прошлых жизней нет.</div>`;
 modalCard.innerHTML=`<h2>Кладбище</h2><div class="modal-line"></div><div class="graves">${html}</div><div class="modal-actions"><button class="big-btn btn-blue" onclick="closeModal()">Закрыть</button></div>`;
 modalRoot.classList.remove("hidden");
}

const oldGraveInfo = graveInfo;
graveInfo = function(i){
 let g=loadJSON(GRAVES,[])[i];
 showModal("Память о жизни",`Здесь покоится ${g.name}.

Возраст: ${g.age} лет
Деньги: ${money(g.money)}
Концовка: ${g.ending}
Дети: ${g.children}
Бизнес: ${g.business}
Могила: ${g.graveType||"Каменное надгробье"}
Причина: ${g.reason}`);
}

const oldCanChoose = canChoose;
canChoose = function(c){
 if(c && c.extra){
   if(c.extra.needRel && game.relationship==="Одинок") return false;
   if(c.extra.needMarriage && game.relationship!=="Брак") return false;
 }
 return oldCanChoose(c);
}

// Перерисовать меню уже после переопределений
renderMenu();




/* ==========================================================
   v15 ONE SCREEN NEWLIFE STYLE
   - старт с 16 лет
   - 100 энергии в месяц
   - один экран без постоянного скролла
   - категории разделены: жизнь/еда/учёба/работа/друзья/семья/отношения/магазин
   - событие + выборы + распределение энергии
   ========================================================== */

let activeCatV15 = "life";

const V15_CATS = [
  {id:"life", name:"Жизнь"},
  {id:"food", name:"Еда"},
  {id:"study", name:"Учёба"},
  {id:"work", name:"Работа"},
  {id:"friends", name:"Друзья"},
  {id:"family", name:"Семья"},
  {id:"love", name:"Любовь"},
  {id:"home", name:"Дом"},
  {id:"bank", name:"Банк"},
  {id:"more", name:"Ещё"},
];

function ensureV15(){
  ensureV14 && ensureV14();
  if(!game) return;
  game.version = 15;
  game.monthlyEnergy = game.monthlyEnergy || 100;
  if(game.monthlyEnergy < 100) game.monthlyEnergy = 100;
  if(game.energy > game.monthlyEnergy) game.energy = game.monthlyEnergy;
  game.age = game.age ?? 16;
  game.lifeFeeling = game.lifeFeeling ?? game.happiness ?? 80;
  game.skills = game.skills || {};
  game.inventory = game.inventory || [];
  game.pets = game.pets || [];
  game.foodPlan = game.foodPlan || "Обычное питание";
  game.sportPlan = game.sportPlan || "Нет";
}

const oldNewGameV15 = newGame;
newGame = function(name="", gender="Мужской"){
  oldNewGameV15(name, gender);
  ensureV15();
  game.age = 16;
  game.month = 0;
  game.totalMonths = 16 * 12;
  game.monthlyEnergy = 100;
  game.energy = 100;
  game.education = "Школа";
  game.school = Math.max(game.school || 0, 40);
  game.money = Math.max(game.money, rand(3000, 30000));
  game.lastResult = "Тебе 16 лет. Жизнь начинается с юности: школа, друзья, первые подработки, отношения и выбор будущего.";
  log("Старт жизни", "Игра начинается с 16 лет. У тебя 100 энергии на месяц. Распредели её между учёбой, отдыхом, друзьями, работой и развитием.");
  currentEvent = generateEvent();
  saveGame();
  renderGame();
}

function choiceCompactHTML(c,i){
  let ok = canChoose(c);
  return `<button class="one-choice ${ok?'':'locked'}" onclick="choose(${i})"><b>${c.text}</b><span>${costText(c)}${c.hint? " • "+c.hint:""}</span></button>`;
}

function barCompact(n,v,c){
  v=clamp(v);
  return `<div><div class="bar-label"><span>${n}</span><span>${v}/100</span></div><div class="track"><div class="fill" style="width:${v}%;background:${c}"></div></div></div>`;
}

function v15Stat(t,v,cls=""){
  return `<div class="one-stat ${cls}"><span>${t}</span><b>${v}</b></div>`;
}

function renderGame(){
  ensureV15();
  if(!game) return renderMenu();
  if(!currentEvent) currentEvent = generateEvent();
  checkLimits(); checkAchievements(); saveGame();
  let jobName = game.job ? game.job.name : "Нет";
  let rel = game.relationship || "Одинок";
  app.innerHTML = `<section class="screen game-screen one-screen">
   <div class="one-page">
    <div class="compact-top">
      <button class="round-btn" onclick="renderMenu()">☰</button>
      <div class="compact-title"><h1>НОВАЯ ЖИЗНЬ</h1><span>${ageMonth()}</span></div>
      <button class="round-btn shop-btn" onclick="showAssets()">Активы</button>
    </div>

    <div class="one-stats">
      ${v15Stat("Возраст", game.age + " лет")}
      ${v15Stat("Деньги", money(game.money), "money")}
      ${v15Stat("Энергия", game.energy + "/" + game.monthlyEnergy, "energy")}
      ${v15Stat("Слава", game.fame, "fame")}
    </div>

    <div class="one-core">
      <section class="one-profile card slide-up">
        <img class="avatar" src="img/${game.gender==='Женский'?'avatar_girl.png':'avatar_boy.png'}">
        <div>
          <div class="one-name">${game.name}</div>
          <div class="one-info">${game.country} | ${game.city} | ${stage()}</div>
          <div class="one-info">Учёба: ${game.education} • Работа: ${jobName}</div>
          <div class="one-info">Отношения: ${rel} • Друзья: ${game.friends} • Дети: ${game.children.length}</div>
          <div class="one-bars">
            ${barCompact("Здоровье",game.health,"#19a84d")}
            ${barCompact("Чувство жизни",game.lifeFeeling,"#f59e0b")}
            ${barCompact("Энергия",game.energy/game.monthlyEnergy*100,"#2f7df4")}
            ${barCompact("Психика",game.mental,"#a855f7")}
          </div>
        </div>
      </section>

      <section class="event-one card slide-up">
        <div class="tag">Событие месяца</div>
        <div class="event-title">${currentEvent.title}</div>
        <div class="event-text">${currentEvent.text}</div>
        <div class="event-meta">Выборы ниже тратят энергию. Месяц закончится только по кнопке.</div>
      </section>

      <section class="one-actions card slide-up">
        <div class="category-strip">
          ${V15_CATS.slice(0,10).map(c=>`<button class="cat-tab ${activeCatV15===c.id?'active':''}" onclick="setCatV15('${c.id}')">${c.name}</button>`).join("")}
        </div>
        <div class="category-panel">
          <div class="category-title"><b>${catTitleV15(activeCatV15)}</b><span>Энергия: ${game.energy}/${game.monthlyEnergy}</span></div>
          <div class="category-actions">
            ${actionsForCatV15(activeCatV15).slice(0,6).map((a,i)=>catActionHTML(a,i)).join("")}
          </div>
        </div>
      </section>
    </div>

    <nav class="one-bottom">
      <button class="primary" onclick="showEventChoicesV15()">Событие</button>
      <button onclick="showDiary()">Дневник</button>
      <button onclick="showStats()">Статы</button>
      <button class="month" onclick="nextMonth()">Месяц +</button>
    </nav>
   </div>
  </section>`;
  applyMusic();
}

function setCatV15(id){
  activeCatV15 = id;
  renderGame();
}

function catTitleV15(id){
  return ({
    life:"Жизнь и развитие",
    food:"Еда, спорт и здоровье",
    study:"Учёба и навыки",
    work:"Работа и фриланс",
    friends:"Друзья и знакомые",
    family:"Семья и родственники",
    love:"Отношения и любовь",
    home:"Жильё и транспорт",
    bank:"Банк и инвестиции",
    more:"Бизнес, путешествия, питомцы"
  })[id] || "Действия";
}

function catActionHTML(a,i){
  let ok = canChoose(a);
  let cls = ["btn-blue","btn-green","btn-purple","btn-red","btn-orange","btn-blue"][i%6];
  if(!ok) cls = "btn-gray";
  return `<button class="cat-action ${cls}" onclick="doCatActionV15(${i})"><b>${a.text}</b><span>${costText(a)}${a.hint? " • "+a.hint:""}</span></button>`;
}

function doCatActionV15(i){
  let a = actionsForCatV15(activeCatV15)[i];
  if(!a) return;
  if(!canChoose(a)){ toast("Не хватает энергии, денег или условий"); return; }
  vibrate();
  if(a.cost) game.energy -= a.cost;
  if(a.money) game.money -= a.money;
  let res = applyEffects(a.effects || {}, a.result || "Действие выполнено.");
  game.lastResult = res;
  log(catTitleV15(activeCatV15), `${a.text}: ${res}`);
  checkDeath();
  renderGame();
}

function showEventChoicesV15(){
  ensureV15();
  showActionModal(currentEvent.title, currentEvent.choices);
}

function actionsForCatV15(cat){
  ensureV15();
  if(cat==="life") return [
    ch("Отдохнуть дома",0,{energy:18,lifeFeeling:5,stress:-8,mental:5},"Ты восстановил силы после напряжённых дней."),
    ch("Прогулка",8,{lifeFeeling:7,health:2,stress:-4},"Прогулка помогла освежить мысли."),
    ch("Хобби",12,{creativity:12,lifeFeeling:8,mental:4},"Хобби дало вдохновение."),
    ch("Самоанализ",10,{mental:10,discipline:3,lifeFeeling:4},"Ты лучше понял, чего хочешь от жизни."),
    ch("Игры / досуг",10,{lifeFeeling:10,stress:-6,discipline:-1},"Ты отвлёкся и перезагрузился."),
    ch("Волонтёрство",14,{karma:10,charisma:5,lifeFeeling:9},"Ты сделал полезное дело и почувствовал смысл.")
  ];

  if(cat==="food") return [
    ch("Домашняя еда",6,{foodPlan:"Домашнее питание",health:5,lifeFeeling:3},"Нормальное питание поддерживает силы.",{money:3000}),
    ch("Фастфуд",4,{foodPlan:"Фастфуд",health:-4,lifeFeeling:5},"Быстро и вкусно, но не очень полезно.",{money:1500}),
    ch("Диета",10,{foodPlan:"Индивидуальная диета",health:12,looks:4,discipline:3},"Диета улучшила самочувствие.",{money:18000}),
    ch("Зарядка",8,{health:8,discipline:3,stress:-2},"Короткая зарядка дала бодрость."),
    ch("Тренажёрный зал",16,{sportPlan:"Зал",health:14,looks:7,discipline:5},"Тренировка была тяжёлой, но полезной.",{money:9000}),
    ch("Лечение",12,{health:22,mental:5,disease:"Нет"},"Лечение помогло восстановиться.",{money:25000})
  ];

  if(cat==="study") return [
    ch("Школа / уроки",18,{mind:18,discipline:8,school:10},"Ты серьёзно занялся учёбой."),
    ch("Программирование",18,{skill:["Программирование",25],mind:12},"Ты разобрал новую тему в программировании.",{money:5000}),
    ch("Английский",14,{skill:["Английский",22],mind:8,charisma:3},"Английский стал увереннее.",{money:4000}),
    ch("Дизайн",14,{skill:["Дизайн",22],creativity:10},"Ты развил чувство визуала.",{money:5000}),
    ch("Блогинг",12,{skill:["Блоггинг",18],charisma:7,fame:3},"Ты изучил, как развивать личный бренд."),
    ch("Финансы",12,{skill:["Финансовая грамотность",18],mind:8},"Ты стал лучше понимать деньги.",{money:4000})
  ];

  if(cat==="work") {
    let list = [
      ch("Подработка",18,{money:rand(3000,15000),discipline:4,stress:2},"Подработка дала первые деньги.",{need:{age:16}}),
      ch("Фриланс-заказ",22,{money:rand(12000,70000),mind:5,stress:4},"Ты выполнил фриланс-заказ.",{need:{age:16}}),
      ch("Вести блог",18,{fame:rand(5,25),charisma:6,skill:["Блоггинг",10]},"Публикация получила отклик."),
      ch("Посмотреть вакансии",8,{discipline:2},"Ты изучил вакансии и требования."),
      ch("Попросить повышение",14,{career:8,charisma:5,stress:3},"Ты обсудил карьерный рост."),
      ch("Уволиться",0,{job:null,stress:-8,lifeFeeling:3},"Ты ушёл с работы.")
    ];
    if(game.age >= 18){
      list[0] = ch("Найти работу",16,{flag:"job_search",discipline:4},"Ты начал искать постоянную работу.");
    }
    return list;
  }

  if(cat==="friends") return [
    ch("Познакомиться",10,{acquaintances:rand(1,3),charisma:5,lifeFeeling:4},"Ты познакомился с новыми людьми."),
    ch("Встретиться с друзьями",14,{friend:1,lifeFeeling:10,stress:-5,charisma:3},"Встреча с друзьями подняла настроение."),
    ch("Помочь другу",12,{friend:1,karma:6,lifeFeeling:5},"Друг оценил твою поддержку."),
    ch("Попросить помощи",6,{money:rand(1000,10000),friend:-1},"Друг помог, но это немного повлияло на отношения."),
    ch("Общий проект",18,{mind:7,charisma:7,fame:2},"Вы с друзьями придумали общий проект."),
    ch("Ссора",4,{friend:-1,stress:6,lifeFeeling:-4},"Конфликт испортил настроение.")
  ];

  if(cat==="family") return [
    ch("Поговорить с родителями",8,{parents:8,lifeFeeling:5,mental:3},"Разговор с родителями был тёплым."),
    ch("Помочь по дому",10,{parents:10,discipline:4,lifeFeeling:3},"Родители заметили твою помощь."),
    ch("Помочь деньгами",6,{parents:12,karma:8},"Ты помог семье финансово.",{money:15000}),
    ch("Семейный вечер",14,{parents:12,lifeFeeling:12,stress:-4},"Семейный вечер стал приятным воспоминанием.",{money:5000}),
    ch("Поговорить с детьми",12,{lifeFeeling:12,karma:6},"Ты уделил время детям."),
    ch("Развитие детей",16,{karma:10,stress:-2},"Ты вложился в развитие детей.",{money:20000})
  ];

  if(cat==="love") return [
    ch("Искать отношения",12,{partner:1,charisma:8,lifeFeeling:6},"Ты встретил интересного человека.",{need:{age:16}}),
    ch("Свидание",14,{love:16,lifeFeeling:12,charisma:4},"Свидание прошло хорошо.",{money:5000}),
    ch("Подарок",8,{love:12,lifeFeeling:4},"Подарок порадовал партнёра.",{money:10000}),
    ch("Разговор по душам",8,{love:14,mental:6},"Вы лучше поняли друг друга."),
    ch("Предложение",12,{relationship:"Брак",love:25,lifeFeeling:20},"Ты сделал предложение, и это стало важным моментом.",{money:80000,need:{age:18}}),
    ch("Ребёнок",18,{child:1,lifeFeeling:18,stress:5},"В семье появился ребёнок.",{money:50000,need:{age:18}})
  ];

  if(cat==="home") return [
    ch("Снять комнату",5,{rent:"Комната",lifeFeeling:3},"Ты снял комнату.",{money:20000,need:{age:18}}),
    ch("Снять квартиру",5,{rent:"Квартира",lifeFeeling:6},"Ты снял квартиру.",{money:60000,need:{age:18}}),
    ch("Купить квартиру",8,{home:"flat",lifeFeeling:10},"Ты купил квартиру.",{money:850000,need:{age:18}}),
    ch("Купить дом",8,{home:"house",lifeFeeling:15},"Ты купил дом.",{money:3500000,need:{age:18}}),
    ch("Купить машину",6,{car:"car",fame:6,lifeFeeling:5},"Ты купил машину.",{money:900000,need:{age:18}}),
    ch("Ремонт",12,{lifeFeeling:8,stress:-5},"Ремонт сделал жильё уютнее.",{money:50000})
  ];

  if(cat==="bank") return [
    ch("Вложить в акции",6,{shares:50000},"Ты купил акции.",{money:50000,need:{age:18}}),
    ch("Криптовалюта",8,{crypto:50000},"Ты рискнул вложиться в криптовалюту.",{money:50000,need:{age:18}}),
    ch("Кредит 500к",2,{money:500000,debt:650000,stress:6},"Банк выдал кредит.",{need:{age:18}}),
    ch("Погасить 100к",4,{debt:-100000,stress:-4},"Ты погасил часть долга.",{money:100000,need:{age:18}}),
    ch("Финансовый план",8,{skill:["Финансовая грамотность",12],discipline:5,stress:-3},"Ты навёл порядок в финансах."),
    ch("Копить деньги",6,{money:rand(5000,25000),discipline:4,lifeFeeling:-1},"Ты отложил часть денег.")
  ];

  if(cat==="more") return [
    ch("Открыть бизнес",28,{business:1,businessReputation:10,businessName:"Малый бизнес",stress:5},"Ты запустил свой бизнес.",{money:250000,need:{age:18}}),
    ch("Улучшить бизнес",24,{business:1,businessReputation:18,stress:5},"Бизнес стал сильнее.",{money:200000,need:{age:18}}),
    ch("Путешествие",24,{travelCity:"Париж",lifeFeeling:20,charisma:5,stress:-8},"Путешествие стало ярким событием.",{money:90000}),
    ch("Купить питомца",10,{pet:"Кот",lifeFeeling:10,stress:-5},"Питомец сделал дом теплее.",{money:15000}),
    ch("Купить компьютер",6,{inventory:"pc_basic",skill:["Программирование",10],mind:10},"Компьютер открыл новые возможности.",{money:65000}),
    ch("Бессмертие",40,{immortal:true,health:100,mental:100,lifeFeeling:100},"Ты купил таблетку бессмертия.",{money:10000000,need:{age:45,mind:1000,fame:700,business:5}})
  ];

  return [];
}

const oldGenerateEventV15 = generateEvent;
generateEvent = function(){
  ensureV15();
  let A = game.age;
  let pool = [];

  if(A >= 16 && A <= 17){
    pool.push(
      ev("Выбор после школы", "Учителя говорят, что пора думать о будущем. Одни одноклассники мечтают об университете, другие уже ищут подработку, а кто-то хочет стать популярным в интернете. Этот месяц может определить твой старт.", "юность", [
        ch("Готовиться к экзаменам",18,{mind:22,discipline:10,school:12},"Ты серьёзно взялся за учёбу. Будущие поступления станут легче."),
        ch("Найти подработку",20,{money:rand(5000,22000),discipline:5,stress:3},"Ты получил первые рабочие деньги и понял цену времени."),
        ch("Развивать блог",18,{fame:rand(8,30),charisma:8,skill:["Блоггинг",10]},"Ты выложил несколько постов и начал собирать аудиторию."),
        ch("Проводить время с друзьями",14,{friend:1,lifeFeeling:12,charisma:5},"Ты укрепил дружбу и получил яркие воспоминания.")
      ]),
      ev("Компания зовёт гулять", "Друзья зовут тебя на вечернюю прогулку. Родители просят не задерживаться, потому что завтра важный день в школе.", "друзья", [
        ch("Пойти и вернуться вовремя",12,{friend:1,lifeFeeling:10,parents:3,discipline:2},"Ты отлично провёл время и не испортил отношения дома."),
        ch("Задержаться допоздна",16,{lifeFeeling:14,charisma:6,parents:-8,discipline:-4},"Вечер был весёлым, но дома тебя ждал серьёзный разговор."),
        ch("Остаться учиться",18,{mind:18,discipline:8,school:10},"Ты пропустил прогулку, зато стал увереннее в учёбе."),
        ch("Пригласить всех к себе",14,{friend:2,parents:2,lifeFeeling:9},"Домашняя встреча прошла спокойно и весело.",{money:3000})
      ])
    );
  }

  if(A >= 18 && A <= 25){
    pool.push(
      ev("Взрослая развилка", "Ты уже достаточно взрослый, чтобы выбирать направление жизни: образование, работа, переезд, отношения или свой проект. Каждое решение заберёт часть энергии месяца.", "молодость", [
        ch("Поступить на курсы",20,{mind:25,discipline:8,skill:["Программирование",12]},"Ты вложился в навыки, которые помогут зарабатывать.",{money:30000}),
        ch("Искать постоянную работу",18,{flag:"job_search",discipline:6},"Ты начал искать стабильную работу."),
        ch("Сфокусироваться на отношениях",14,{charisma:10,love:8,lifeFeeling:10},"Ты уделил внимание личной жизни."),
        ch("Переехать в новый город",24,{city:"новый город",charisma:6,lifeFeeling:12},"Переезд дал ощущение новой главы.",{money:80000})
      ]),
      ev("Первый серьёзный доход", "Появился шанс заработать больше обычного: временный проект, фриланс или рискованная сделка. Можно вложиться в будущее или выбрать спокойствие.", "деньги", [
        ch("Взять фриланс",22,{money:rand(30000,120000),mind:8,stress:5},"Фриланс дал деньги и опыт."),
        ch("Вложить в обучение",20,{mind:25,skill:["Финансовая грамотность",15],discipline:5},"Ты решил прокачать себя, а не гнаться за быстрыми деньгами.",{money:25000}),
        ch("Рискнуть с криптой",12,{crypto:50000,stress:4},"Ты вложился в рискованный актив.",{money:50000}),
        ch("Отдохнуть и не рисковать",0,{energy:20,stress:-8,lifeFeeling:6},"Ты сохранил силы и нервы.")
      ])
    );
  }

  if(A >= 26){
    pool.push(
      ev("Баланс жизни", "Работа, деньги, здоровье, отношения и семья начинают конкурировать за твоё время. Месяц короткий, энергии всего 100, и нужно выбрать главное.", "взрослая жизнь", [
        ch("Карьерный рывок",26,{career:16,mind:10,stress:8},"Ты вложил силы в карьеру. Это может окупиться позже."),
        ch("Время с семьёй",18,{lifeFeeling:18,love:8,parents:5,stress:-4},"Семейное время вернуло чувство опоры."),
        ch("Здоровье и спорт",18,{health:18,mental:8,discipline:5},"Ты занялся здоровьем, пока проблемы не стали серьёзными."),
        ch("Бизнес-идея",28,{business:1,businessReputation:12,stress:6},"Ты сделал шаг к собственному делу.",{money:180000})
      ]),
      ev("Неожиданное событие", "Месяц принёс ситуацию, которую нельзя полностью контролировать. То, как ты поступишь, повлияет на отношения, здоровье и деньги.", "случайное", [
        ch("Решать спокойно",14,{mental:8,discipline:5,stress:-4},"Ты справился без паники."),
        ch("Попросить помощи",8,{friend:1,charisma:4,lifeFeeling:5},"Поддержка людей помогла."),
        ch("Заплатить и закрыть вопрос",6,{stress:-8,lifeFeeling:3},"Ты решил проблему деньгами.",{money:40000}),
        ch("Игнорировать",0,{stress:10,lifeFeeling:-6},"Проблема не исчезла, а настроение стало хуже.")
      ])
    );
  }

  pool.push(
    ev("Обычный месяц", "Ничего грандиозного не произошло, но именно из обычных месяцев складывается жизнь. Можно развиваться, отдыхать, общаться или зарабатывать.", "обычное", [
      ch("Развиваться",18,{mind:15,discipline:6},"Ты сделал шаг к лучшей версии себя."),
      ch("Общаться",14,{friend:1,charisma:6,lifeFeeling:8},"Общение сделало месяц теплее."),
      ch("Зарабатывать",22,{money:rand(10000,80000),stress:5},"Ты использовал месяц для заработка."),
      ch("Восстановиться",0,{energy:25,mental:8,stress:-10},"Ты позволил себе восстановиться.")
    ])
  );

  return choice(pool);
}

const oldNextMonthV15 = nextMonth;
nextMonth = function(){
  ensureV15();
  oldNextMonthV15();
  ensureV15();
  game.monthlyEnergy = 100;
  game.energy = 100;
  if(game.job){
    game.energy = Math.max(0, game.energy - Math.min(30, game.job.energy * 5));
  }
  if(game.children.length){
    game.energy = Math.max(0, game.energy - Math.min(20, game.children.length * 5));
  }
  if(game.relationship === "Брак"){
    game.energy = Math.max(0, game.energy - 8);
  }
  game.lifeFeeling = clamp(game.lifeFeeling ?? game.happiness);
  saveGame();
  renderGame();
}

// Перерисовка меню после загрузки v15
renderMenu();




/* ==========================================================
   v16 CHILDHOOD SETUP
   Стартовый экран как в примере:
   0 лет → распределение 15 очков → "Прожить 16 лет"
   → старт в 16 лет с начальными характеристиками.
   ========================================================== */

let setupHelpVisibleV16 = true;

const SETUP_ACTIONS_V16 = [
  {
    id:"toys",
    title:"Играть в игрушки",
    cost:2,
    desc:"Развивает воображение, спокойствие и базовое счастье.",
    apply:g=>{ g.creativity+=5; g.lifeFeeling+=3; g.happiness+=2; }
  },
  {
    id:"draw",
    title:"Рисовать",
    cost:1,
    desc:"Развивает творчество, внимательность и будущий интерес к дизайну.",
    apply:g=>{ g.creativity+=7; g.skills["Дизайн"]=(g.skills["Дизайн"]||0)+3; g.mind+=1; }
  },
  {
    id:"sweet",
    title:"Есть сладкое",
    cost:3,
    desc:"Даёт радость в детстве, но немного ухудшает здоровье и дисциплину.",
    apply:g=>{ g.lifeFeeling+=6; g.happiness+=5; g.health-=3; g.discipline-=1; }
  },
  {
    id:"walk",
    title:"Гулять",
    cost:3,
    desc:"Укрепляет здоровье, настроение и открытость к миру.",
    apply:g=>{ g.health+=6; g.lifeFeeling+=4; g.charisma+=2; g.mental+=2; }
  },
  {
    id:"run",
    title:"Бегать и прыгать",
    cost:1,
    desc:"Развивает здоровье, активность и дисциплину.",
    apply:g=>{ g.health+=4; g.discipline+=3; g.looks+=1; }
  },
  {
    id:"cartoons",
    title:"Смотреть мультики",
    cost:2,
    desc:"Даёт настроение и фантазию, но почти не развивает дисциплину.",
    apply:g=>{ g.lifeFeeling+=4; g.creativity+=3; g.discipline-=1; }
  },
  {
    id:"dance",
    title:"Танцевать",
    cost:2,
    desc:"Развивает харизму, творчество и уверенность в себе.",
    apply:g=>{ g.charisma+=5; g.creativity+=4; g.looks+=2; }
  },
  {
    id:"friends",
    title:"Играть с друзьями",
    cost:1,
    desc:"Развивает общительность, друзей и чувство жизни.",
    apply:g=>{ g.friends+=1; g.charisma+=4; g.lifeFeeling+=4; }
  }
];

function setupSpentV16(){
  if(!game || !game.setupPicks) return 0;
  return Object.entries(game.setupPicks).reduce((s,[id,count])=>{
    const a = SETUP_ACTIONS_V16.find(x=>x.id===id);
    return s + (a ? a.cost * count : 0);
  },0);
}

function setupLeftV16(){
  return Math.max(0, (game?.setupEnergyMax || 15) - setupSpentV16());
}

function renderSetupV16(){
  ensureV15 && ensureV15();
  const left = setupLeftV16();
  const healthPreview = clamp(50 + (game.setupPreviewHealth || 0),0,100);
  const happyPreview = clamp(20 + (game.setupPreviewHappy || 0),0,100);
  app.innerHTML = `<section class="setup-screen">
    <div class="setup-page">
      <div class="setup-top">
        <div>${game.name} 0 лет</div>
        <div class="center">⚡ ${left}</div>
        <div style="text-align:right">${money(0)}</div>
      </div>

      <div class="setup-bars">
        <div class="setup-barline">
          <div class="setup-emoji">❤️</div>
          <div class="setup-track"><div class="setup-fill" style="width:${healthPreview}%"></div></div>
        </div>
        <div class="setup-barline">
          <div class="setup-emoji">🙂</div>
          <div class="setup-track"><div class="setup-fill happy" style="width:${happyPreview}%"></div></div>
        </div>
      </div>

      <div class="setup-actions">
        ${SETUP_ACTIONS_V16.map(a=>{
          const count = game.setupPicks[a.id] || 0;
          const can = left >= a.cost;
          return `<button class="setup-action ${count>0?'active':''} ${!can?'disabled':''}" onclick="pickSetupV16('${a.id}')">${a.title} (${count})</button>`;
        }).join("")}
      </div>

      <div class="setup-footer">
        <button class="setup-advance" onclick="finishSetupV16()">Прожить 16 лет</button>
      </div>
    </div>

    <div id="setupHelpV16" class="setup-dialog ${setupHelpVisibleV16?'':'hidden'}">
      Добро пожаловать в жизнь, ${game.name}!<br>
      Первые 16 лет пролетят незаметно.<br><br>
      Распредели очки действий между детскими занятиями.
      От выбора зависят начальные характеристики в 16 лет.
      <button onclick="hideSetupHelpV16()">Понятно</button>
    </div>
  </section>`;
  applyMusic();
}

function hideSetupHelpV16(){
  setupHelpVisibleV16 = false;
  renderSetupV16();
}

function pickSetupV16(id){
  const a = SETUP_ACTIONS_V16.find(x=>x.id===id);
  if(!a) return;
  if(setupLeftV16() < a.cost){
    toast("Не хватает очков детства");
    return;
  }
  vibrate();
  game.setupPicks[id] = (game.setupPicks[id] || 0) + 1;
  game.setupPreviewHealth = 0;
  game.setupPreviewHappy = 0;
  for(const [pid,count] of Object.entries(game.setupPicks)){
    const act = SETUP_ACTIONS_V16.find(x=>x.id===pid);
    if(!act) continue;
    for(let i=0;i<count;i++){
      if(pid==="sweet"){ game.setupPreviewHappy += 7; game.setupPreviewHealth -= 3; }
      if(pid==="walk"){ game.setupPreviewHealth += 5; game.setupPreviewHappy += 2; }
      if(pid==="run"){ game.setupPreviewHealth += 4; }
      if(pid==="friends"){ game.setupPreviewHappy += 4; }
      if(pid==="toys"){ game.setupPreviewHappy += 3; }
      if(pid==="cartoons"){ game.setupPreviewHappy += 3; }
      if(pid==="dance"){ game.setupPreviewHappy += 2; }
    }
  }
  saveGame();
  renderSetupV16();
}

function finishSetupV16(){
  ensureV15 && ensureV15();
  if(setupSpentV16() <= 0){
    toast("Сначала выбери хотя бы одно занятие");
    return;
  }

  game.setupMode = false;

  // База в 16 лет
  game.age = 16;
  game.month = 0;
  game.totalMonths = 16 * 12;
  game.monthlyEnergy = 100;
  game.energy = 100;
  game.education = "Школа";
  game.school = 35;
  game.money = rand(2000, 25000);
  game.health = 70;
  game.lifeFeeling = 60;
  game.happiness = 60;
  game.mental = 65;
  game.looks = rand(28,65);
  game.mind = 10;
  game.charisma = 5;
  game.creativity = 5;
  game.discipline = 5;
  game.fame = 0;
  game.friends = 0;
  game.acquaintances = 0;
  game.job = null;
  game.relationship = "Одинок";
  game.children = [];
  game.skills = game.skills || {};
  V14_SKILLS.forEach(s=>{ if(game.skills[s]===undefined) game.skills[s]=0; });

  let lines = [];
  for(const [id,count] of Object.entries(game.setupPicks)){
    const a = SETUP_ACTIONS_V16.find(x=>x.id===id);
    if(!a || count <= 0) continue;
    for(let i=0;i<count;i++) a.apply(game);
    lines.push(`${a.title}: ${count} раз. ${a.desc}`);
  }

  game.health = clamp(game.health);
  game.lifeFeeling = clamp(game.lifeFeeling);
  game.happiness = clamp(game.happiness);
  game.mental = clamp(game.mental);
  game.discipline = Math.max(0, game.discipline);
  game.looks = clamp(game.looks);

  game.lastResult = `Первые 16 лет прошли. Детские занятия сформировали твои стартовые качества. Теперь начинается юность: школа, друзья, первые деньги, отношения и выбор будущего.`;
  log("Первые 16 лет", lines.join("\n"));
  currentEvent = generateEvent();
  saveGame();

  modalCard.innerHTML = `<h2>Тебе 16 лет</h2>
    <div class="modal-line"></div>
    <div class="modal-text">Детство сформировало стартовые характеристики.

Здоровье: ${game.health}/100
Чувство жизни: ${game.lifeFeeling}/100
Ум: ${game.mind}
Харизма: ${game.charisma}
Творчество: ${game.creativity}
Дисциплина: ${game.discipline}
Друзья: ${game.friends}

Теперь начинается настоящая игра.</div>
    <div class="modal-actions"><button class="big-btn btn-blue" onclick="closeModal(); renderGame();">Начать в 16 лет</button></div>`;
  modalRoot.classList.remove("hidden");
}

const oldNewGameV16 = newGame;
newGame = function(name="", gender="Мужской"){
  // Создаём обычного персонажа через старую функцию, потом переводим в setup 0 лет.
  oldNewGameV16(name, gender);
  ensureV15 && ensureV15();

  game.setupMode = true;
  game.setupEnergyMax = 15;
  game.setupPicks = {};
  game.setupPreviewHealth = 0;
  game.setupPreviewHappy = 0;

  game.age = 0;
  game.month = 0;
  game.totalMonths = 0;
  game.money = 0;
  game.energy = 15;
  game.monthlyEnergy = 15;

  game.health = 50;
  game.lifeFeeling = 20;
  game.happiness = 20;
  game.mental = 50;
  game.mind = 0;
  game.charisma = 0;
  game.creativity = 0;
  game.discipline = 0;
  game.fame = 0;
  game.friends = 0;
  game.job = null;
  game.relationship = "Одинок";
  game.education = "Нет";
  game.lastResult = "Добро пожаловать в жизнь. Распредели первые очки детства.";

  setupHelpVisibleV16 = true;
  saveGame();
  renderSetupV16();
}

const oldRenderGameV16 = renderGame;
renderGame = function(){
  if(game && game.setupMode){
    return renderSetupV16();
  }
  return oldRenderGameV16();
}

const oldContinueGameV16 = continueGame;
continueGame = function(){
  if(game && game.setupMode) return renderSetupV16();
  return oldContinueGameV16();
}

renderMenu();
