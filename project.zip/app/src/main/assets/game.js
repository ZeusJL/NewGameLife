const $ = q => document.querySelector(q);
const app = $("#app");
const modalRoot = $("#modalRoot");
const modalCard = $("#modalCard");
const music = $("#bgMusic");
const toastBox = $("#toast");

const SAVE = "newlife_story_save_v12";
const GRAVES = "newlife_story_graves_v12";
const SETTINGS = "newlife_story_settings_v12";

let settings = loadJSON(SETTINGS, { music:true, sound:true, vibration:true, autosave:true, cloud:false, google:false });
let game = loadJSON(SAVE, null);
let currentEvent = null;
let currentTab = "main";

function loadJSON(k, f){ try { const v = JSON.parse(localStorage.getItem(k)); return v ?? f; } catch(e){ return f; } }
function saveJSON(k, v){ localStorage.setItem(k, JSON.stringify(v)); }
function rand(a,b){ return Math.floor(Math.random()*(b-a+1))+a; }
function chance(p){ return rand(1,100) <= p; }
function pick(arr){ return arr[Math.floor(Math.random()*arr.length)]; }
function clamp(v,a=0,b=100){ return Math.max(a, Math.min(b, Math.round(v))); }
function money(n){ return Math.round(n).toLocaleString("ru-RU") + " ₽"; }
function vibrate(ms=20){ if(settings.vibration && navigator.vibrate) navigator.vibrate(ms); }
function toast(t){ toastBox.textContent=t; toastBox.classList.add("show"); setTimeout(()=>toastBox.classList.remove("show"), 1800); }
function applyMusic(){ if(settings.music){ music.volume=.16; music.play().catch(()=>{}); } else music.pause(); }
function saveGame(){ if(settings.autosave && game) saveJSON(SAVE, game); }
function ageYears(){ return Math.floor(game.month / 12); }
function monthName(){ return ["Январь","Февраль","Март","Апрель","Май","Июнь","Июль","Август","Сентябрь","Октябрь","Ноябрь","Декабрь"][game.month % 12]; }
function stage(){ const a=ageYears(); if(game.immortal) return "Бессмертный"; if(a<3) return "Младенец"; if(a<7) return "Детство"; if(a<14) return "Школа"; if(a<18) return "Подросток"; if(a<26) return "Молодость"; if(a<60) return "Взрослая жизнь"; return "Старость"; }
function stat(k, d){ game[k] = clamp((game[k] ?? 0) + d); }
function add(k, d){ game[k] = Math.max(0, Math.round((game[k] ?? 0) + d)); }
function spend(v){ if(game.money < v) return false; game.money -= v; return true; }
function addLog(text){ game.diary.unshift({ age: ageYears(), month: monthName(), text }); game.diary = game.diary.slice(0, 120); }
function addAchievement(name){ if(!game.achievements.includes(name)){ game.achievements.push(name); addLog("Достижение: " + name); } }

const jobs = [
  {id:"courier", name:"Курьер", minAge:14, req:{}, salary:22000, stress:8, fame:0},
  {id:"cashier", name:"Кассир", minAge:16, req:{}, salary:30000, stress:10, fame:0},
  {id:"driver", name:"Водитель", minAge:18, req:{discipline:25}, salary:52000, stress:12, fame:1},
  {id:"designer", name:"Дизайнер", minAge:18, req:{creativity:90}, salary:76000, stress:10, fame:4},
  {id:"programmer", name:"Программист", minAge:18, req:{mind:170}, salary:130000, stress:14, fame:3},
  {id:"doctor", name:"Врач", minAge:24, req:{education:"Медицинское", mind:320}, salary:160000, stress:22, fame:6},
  {id:"lawyer", name:"Юрист", minAge:22, req:{education:"Юридическое", charisma:80}, salary:150000, stress:18, fame:5},
  {id:"blogger", name:"Блогер", minAge:14, req:{charisma:85}, salary:90000, stress:13, fame:16},
  {id:"actor", name:"Актёр", minAge:18, req:{charisma:140, creativity:120}, salary:140000, stress:16, fame:20},
  {id:"scientist", name:"Учёный", minAge:24, req:{education:"Высшее", mind:420}, salary:135000, stress:15, fame:7},
  {id:"director", name:"Директор", minAge:26, req:{mind:350, charisma:220, discipline:180}, salary:250000, stress:24, fame:12},
  {id:"politician", name:"Политик", minAge:30, req:{fame:300, charisma:300}, salary:300000, stress:30, fame:30}
];

const countries = [
  {name:"Россия", mult:1, life:77}, {name:"США", mult:2.1, life:79}, {name:"Германия", mult:1.8, life:81},
  {name:"Япония", mult:1.7, life:84}, {name:"Швейцария", mult:2.6, life:84}, {name:"Бразилия", mult:1.2, life:76}
];

function newGame(name="", gender="Мужской"){
  const country = pick(countries);
  const familyRoll = rand(1,100);
  let family = "Обычная семья", cash = rand(5000,35000), pressure = 10, support = 40;
  if(familyRoll <= 16){ family = "Бедная семья"; cash = rand(0,6000); pressure = 25; support = 20; }
  if(familyRoll >= 86){ family = "Богатая семья"; cash = rand(90000,250000); pressure = 18; support = 75; }
  game = {
    name: name || pick(gender==="Женский" ? ["Анна","Мария","София","Кира","Алиса","Ева"] : ["Денис","Максим","Артём","Иван","Лев","Марк"]),
    gender, country: country.name, countryMult: country.mult, expectedLife: country.life, city: pick(["обычный город","маленький город","мегаполис","пригород"]),
    month:0, money:cash, familyStatus:family, familySupport:support, familyPressure:pressure,
    health:100, happiness:75 + Math.floor(support/12), energy:100, mental:100,
    mind:0, charisma:0, creativity:0, discipline:0, looks:rand(30,90), luck:rand(1,10), fame:0,
    education:"Нет", school:0, college:0, university:0, med:0, law:0,
    job:null, jobLevel:0, jobExp:0, business:0, businessName:"", freelance:0,
    relationship:"Одинок", partner:null, love:0, friends:0, bestFriend:null, children:[], parentsAlive:true,
    home:"С родителями", homeLevel:0, transport:"Нет", carLevel:0, pet:null,
    debt:0, shares:0, crypto:0, realEstate:0,
    disease:null, addictions:0, criminal:0, reputation:0,
    immortal:false, immortalBought:false, gameOver:false, ending:null, deathReason:null,
    achievements:[], diary:[], flags:{}, choicesMade:0, lastText:"Ты появился на свет. Впереди целая жизнь.",
    createdAt:Date.now()
  };
  addLog("Рождение: " + game.name + ", " + game.country + ", " + game.familyStatus + ".");
  currentEvent = makeEvent("Рождение", "Ты родился в стране: " + game.country + ". Семья: " + game.familyStatus + ". Первая глава жизни начинается.", [
    choiceBtn("Начать жизнь", () => { passMonths(1, "Началась новая жизнь."); })
  ]);
  currentTab="main"; saveGame(); renderGame();
}

function choiceBtn(text, apply, hint="") { return { text, hint, apply }; }
function makeEvent(title, text, choices){ return { title, text, choices }; }
function choiceEffects(obj){
  return () => {
    Object.entries(obj.stats || {}).forEach(([k,v]) => stat(k,v));
    Object.entries(obj.add || {}).forEach(([k,v]) => add(k,v));
    if(obj.money) game.money += obj.money;
    if(obj.spend && !spend(obj.spend)){ toast("Не хватает денег"); return false; }
    if(obj.set) Object.entries(obj.set).forEach(([k,v]) => game[k]=v);
    passMonths(obj.months || 1, obj.text || "Выбор сделан.");
  };
}

function passMonths(n=1, log=""){
  if(game.gameOver){ renderGame(); return; }
  game.choicesMade++;
  if(log) { game.lastText = log; addLog(log); }
  for(let i=0;i<n;i++) monthlyTick();
  checkAchievements(); checkEnd();
  currentEvent = game.gameOver ? endingEvent() : generateEvent();
  saveGame(); renderGame();
}

function monthlyTick(){
  game.month++;
  const a = ageYears();
  stat("energy", rand(8,16));
  stat("happiness", rand(-2,2));
  stat("mental", rand(-1,1));
  if(a > 35 && !game.immortal) stat("health", -rand(0,1));
  if(a > 55 && !game.immortal) stat("health", -rand(0,2));
  if(a > 70 && !game.immortal) stat("health", -rand(1,3));
  if(game.disease && !game.immortal) stat("health", -rand(1,6));
  if(game.addictions > 0){ stat("health", -rand(0,2)); stat("mental", -rand(0,2)); }
  if(game.job){
    const j = jobs.find(x=>x.id===game.job.id) || game.job;
    const income = Math.round((j.salary + game.jobLevel*18000 + game.mind*20 + game.fame*8) * game.countryMult / 12);
    game.money += income;
    game.jobExp += rand(2,6);
    stat("energy", -Math.floor(j.stress/2)); stat("mental", -Math.floor(j.stress/3));
  }
  if(game.business > 0){
    const profit = game.business * rand(-6000, 28000);
    game.money += profit;
    if(profit < 0) stat("mental", -3); else add("fame", 1);
  }
  if(game.freelance > 0 && chance(40)) game.money += game.freelance * rand(4000,18000);
  if(game.shares > 0) game.money += rand(-Math.floor(game.shares*.04), Math.floor(game.shares*.075));
  if(game.crypto > 0) game.money += rand(-Math.floor(game.crypto*.14), Math.floor(game.crypto*.19));
  if(game.homeLevel > 0) game.money -= game.homeLevel * 5000;
  if(game.carLevel > 0) game.money -= game.carLevel * 2400;
  if(game.children.length) game.money -= game.children.length * 9000;
  if(game.debt > 0){ const pay = Math.min(game.debt, Math.max(5000, Math.floor(game.debt*.035))); game.debt -= pay; game.money -= pay; }
  game.health=clamp(game.health); game.happiness=clamp(game.happiness); game.energy=clamp(game.energy); game.mental=clamp(game.mental); game.money=Math.round(game.money);
}

function checkAchievements(){
  const a=ageYears();
  const list = [
    ["Первый год", a>=1], ["Школьник", a>=7], ["Взрослая жизнь", a>=18], ["Умный человек", game.mind>=300],
    ["Харизматичный", game.charisma>=250], ["Творец", game.creativity>=250], ["Карьера", game.jobLevel>=3],
    ["Предприниматель", game.business>=1], ["Миллионер", game.money>=1000000], ["Мультимиллионер", game.money>=10000000],
    ["Семьянин", game.children.length>=1], ["Знаменитость", game.fame>=500], ["Долгожитель", a>=90], ["Бессмертный", game.immortal]
  ];
  list.forEach(([name,ok])=>{ if(ok) addAchievement(name); });
}
function checkEnd(){
  const a=ageYears();
  if(game.health <= 0 && !game.immortal) return die("Здоровье упало до нуля");
  if(game.mental <= 0 && !game.immortal) return die("Психика не выдержала жизненных нагрузок");
  if(game.money < -1000000 && !game.flags.bankrupt){ game.flags.bankrupt=true; addLog("Банкротство: долги разрушили финансовую стабильность."); stat("happiness", -25); stat("mental", -20); }
  const risk = Math.max(0, a - game.expectedLife + 5) * 3;
  if(a > game.expectedLife - 5 && chance(risk) && !game.immortal) die("Смерть от старости");
  if(a>16 && game.criminal>80 && chance(8)){ game.flags.prison=true; stat("happiness",-20); stat("fame",5); addLog("Проблемы с законом привели к серьёзным последствиям."); }
}
function die(reason){
  game.gameOver=true; game.deathReason=reason; game.ending = calculateEnding();
  const grave = {name:game.name, age:ageYears(), money:game.money, ending:game.ending, reason, fame:game.fame, children:game.children.length, country:game.country, diary:game.diary.slice(0,12), date:new Date().toLocaleDateString("ru-RU")};
  const list = loadJSON(GRAVES, []); list.unshift(grave); saveJSON(GRAVES, list.slice(0,50));
  addLog("Конец жизни: " + game.ending + ". Причина: " + reason + ".");
}
function calculateEnding(){
  if(game.immortal) return "Бессмертная легенда";
  if(game.money>=50000000 && game.fame>=600) return "Легендарный магнат";
  if(game.fame>=800) return "Мировая знаменитость";
  if(game.children.length>=3 && game.happiness>=70) return "Глава большой семьи";
  if(game.mind>=1200 && game.education!=="Нет") return "Гений своего поколения";
  if(game.business>=7) return "Империя бизнеса";
  if(game.criminal>=90) return "Криминальная судьба";
  if(game.money<0) return "Жизнь в долгах";
  if(game.relationship==="Одинок" && game.children.length===0) return "Одинокий путь";
  if(game.happiness>=80) return "Счастливая жизнь";
  return "Обычная, но уникальная жизнь";
}
function endingEvent(){ return makeEvent("Итог жизни", `${game.name} прожил ${ageYears()} лет.\n\nФинал: ${game.ending}.\nПричина: ${game.deathReason}.\n\nДеньги: ${money(game.money)}\nДети: ${game.children.length}\nИзвестность: ${game.fame}\nДостижения: ${game.achievements.length}`, [ choiceBtn("Новая жизнь", ()=>showNewGame()), choiceBtn("Кладбище", ()=>showGraves()), choiceBtn("Главное меню", ()=>renderMenu()) ]); }

function generateEvent(forced=null){
  if(forced) return forcedEvent(forced);
  const a=ageYears();
  const pool=[];
  if(a<3) pool.push(...babyEvents());
  else if(a<7) pool.push(...childEvents());
  else if(a<14) pool.push(...schoolEvents());
  else if(a<18) pool.push(...teenEvents());
  else if(a<26) pool.push(...youngEvents());
  else if(a<60) pool.push(...adultEvents());
  else pool.push(...oldEvents());
  pool.push(...universalEvents());
  if(game.job) pool.push(...jobEvents());
  if(game.relationship !== "Одинок") pool.push(...relationshipEvents());
  if(game.children.length) pool.push(...parentEvents());
  if(game.business>0) pool.push(...businessEvents());
  if(chance(14)) pool.push(...hardEvents());
  return pick(pool)();
}
function forcedEvent(type){
  const map={life:broadLifeEvent, study:studyEvent, work:workEvent, love:loveEvent, property:propertyEvent, health:healthEvent, money:financeEvent, other:otherEvent};
  return (map[type] || broadLifeEvent)();
}

function babyEvents(){ return [
  ()=>makeEvent("Первые месяцы", "Ты ещё ничего не понимаешь, но уже реагируешь на мир вокруг. Родители спорят, как тебя развивать.", [
    choiceBtn("Больше сна", choiceEffects({stats:{health:8, energy:8}, add:{discipline:1}, text:"Ты рос спокойно и здорово."}), "здоровье"),
    choiceBtn("Игры и внимание", choiceEffects({stats:{happiness:10}, add:{charisma:3}, text:"Ты много смеялся и привыкал к людям."}), "харизма"),
    choiceBtn("Развивающие игрушки", choiceEffects({add:{mind:5, creativity:3}, stats:{energy:-4}, text:"Игрушки помогали познавать мир."}), "ум"),
  ]),
  ()=>makeEvent("Болезнь в детстве", "В семье тревога: у тебя температура. Нужно решить, как действовать.", [
    choiceBtn("Вызвать врача", ()=>{ const cost=game.familyStatus==="Бедная семья"?0:rand(1000,6000); game.money-=cost; stat("health",14); passMonths(1,"Врач помог быстро восстановиться."); }),
    choiceBtn("Лечиться дома", choiceEffects({stats:{health:-8,happiness:-3}, add:{luck:1}, text:"Домашнее лечение сработало не идеально."})),
    choiceBtn("Ничего страшного", choiceEffects({stats:{health:-18,energy:-10}, text:"Болезнь дала осложнения."})),
  ])
];}
function childEvents(){ return [
  ()=>makeEvent("Кружок для ребёнка", "Родители предлагают выбрать занятие. Это может повлиять на характер.", [
    choiceBtn("Спорт", choiceEffects({stats:{health:8,energy:-5}, add:{discipline:8}, text:"Спорт укрепил здоровье и дисциплину."})),
    choiceBtn("Рисование", choiceEffects({stats:{happiness:8}, add:{creativity:12}, text:"Ты начал развивать творческий взгляд на мир."})),
    choiceBtn("Подготовка к школе", choiceEffects({stats:{happiness:-4}, add:{mind:12,discipline:4}, text:"Ранняя подготовка дала преимущество."})),
    choiceBtn("Играть во дворе", choiceEffects({stats:{happiness:12,health:3}, add:{charisma:6,friends:1}, text:"Во дворе появились первые друзья."})),
  ]),
  ()=>makeEvent("Первая дружба", "Рядом появился ребёнок, с которым тебе интересно играть.", [
    choiceBtn("Подружиться", ()=>{ game.friends++; game.bestFriend=game.bestFriend||pick(["Саша","Кирилл","Маша","Аня","Даня"]); stat("happiness",12); add("charisma",7); passMonths(1,"У тебя появился близкий друг: "+game.bestFriend+"."); }),
    choiceBtn("Играть одному", choiceEffects({stats:{happiness:3}, add:{mind:6,creativity:7}, text:"Одиночество развило воображение."})),
    choiceBtn("Поссориться из-за игрушки", choiceEffects({stats:{happiness:-6}, add:{charisma:-1, criminal:2}, text:"Ты поссорился из-за игрушки. Неловкий урок общения."})),
  ]),
  ()=>makeEvent("Семейная поездка", "Семья думает, потратить ли деньги на маленькое путешествие.", [
    choiceBtn("Уговорить родителей", ()=>{ if(game.familySupport<25 && game.money<10000){stat("happiness",-3); passMonths(1,"Семья не смогла позволить поездку.");} else {game.money-=Math.min(game.money,10000); stat("happiness",15); add("charisma",4); passMonths(1,"Поездка оставила яркие воспоминания.");}}),
    choiceBtn("Остаться дома", choiceEffects({stats:{energy:8}, add:{mind:3}, text:"Домашний месяц прошёл спокойно."})),
  ])
];}
function schoolEvents(){ return [
  ()=>makeEvent("Первый день в школе", "Школа шумная и незнакомая. Как себя вести?", [
    choiceBtn("Учиться внимательно", choiceEffects({add:{mind:12,discipline:8,school:12}, stats:{energy:-8}, text:"Ты хорошо начал школьный путь."})),
    choiceBtn("Заводить друзей", choiceEffects({add:{charisma:12,friends:1,school:4}, stats:{happiness:10}, text:"Ты быстро нашёл компанию."})),
    choiceBtn("Шалить", choiceEffects({add:{charisma:4,criminal:4}, stats:{happiness:8}, text:"Весело, но учителя уже тебя запомнили."})),
    choiceBtn("Просить репетитора", ()=>{ const cost=30000; if(game.familySupport>55 || spend(cost)){ add("mind",22); add("school",18); stat("happiness",-3); passMonths(1,"Репетитор серьёзно подтянул знания."); } else { passMonths(1,"На репетитора не хватило денег."); } }),
  ]),
  ()=>makeEvent("Контрольная", "Учитель объявил сложную контрольную работу.", [
    choiceBtn("Готовиться", choiceEffects({add:{mind:15,discipline:10,school:16}, stats:{energy:-12,happiness:-3}, text:"Подготовка помогла получить хорошую оценку."})),
    choiceBtn("Списать", ()=>{ if(chance(50+game.luck*3)){add("school",8); add("criminal",5); passMonths(1,"Списывание прошло незаметно, но привычка опасная.");} else {stat("happiness",-12); add("criminal",3); passMonths(1,"Тебя поймали на списывании.");} }),
    choiceBtn("Положиться на удачу", choiceEffects({add:{luck:1,school:rand(0,10)}, stats:{happiness:2}, text:"Удача частично помогла."})),
  ]),
  ()=>makeEvent("Буллинг", "Одноклассник начал издеваться над слабым учеником.", [
    choiceBtn("Защитить", choiceEffects({add:{charisma:12,reputation:12,friends:1}, stats:{energy:-5}, text:"Ты вступился и заслужил уважение."})),
    choiceBtn("Не вмешиваться", choiceEffects({stats:{mental:-8,happiness:-4}, text:"Ты промолчал, но внутри остался неприятный осадок."})),
    choiceBtn("Присоединиться", choiceEffects({add:{criminal:10,charisma:3}, stats:{happiness:-6}, text:"Тебя приняли в плохую компанию."})),
  ])
];}
function teenEvents(){ return [
  ()=>makeEvent("Подростковый выбор", "Тебе хочется свободы. Впереди важный выбор: кем становиться?", [
    choiceBtn("Упор на учёбу", choiceEffects({add:{mind:22,discipline:15,school:18}, stats:{energy:-12,happiness:-3}, text:"Ты серьёзно взялся за учёбу."})),
    choiceBtn("Социальная жизнь", choiceEffects({add:{charisma:22,friends:2}, stats:{happiness:12,energy:-7}, text:"Ты стал заметнее среди сверстников."})),
    choiceBtn("Творчество", choiceEffects({add:{creativity:25,fame:5}, stats:{happiness:8}, text:"Творчество стало частью характера."})),
    choiceBtn("Подработка", ()=>{ const income=rand(5000,25000); game.money+=income; add("discipline",8); stat("energy",-16); passMonths(1,"Подработка принесла " + money(income) + "."); }),
  ]),
  ()=>makeEvent("Первая любовь", "Кто-то из окружения проявляет симпатию.", [
    choiceBtn("Ответить взаимностью", ()=>{ game.relationship="Влюблён"; game.partner=pick(["Аня","Саша","Кира","Макс","Лена","Дима"]); game.love=rand(25,55); stat("happiness",18); add("charisma",8); passMonths(1,"Началась первая влюблённость с " + game.partner + "."); }),
    choiceBtn("Сосредоточиться на себе", choiceEffects({add:{mind:10,discipline:8}, stats:{happiness:-2}, text:"Ты решил не отвлекаться."})),
    choiceBtn("Использовать ради популярности", choiceEffects({add:{fame:12,charisma:10,criminal:3}, stats:{mental:-5}, text:"Популярность выросла, но поступок был сомнительным."})),
  ]),
  ()=>makeEvent("Экзамены близко", "От экзаменов зависит дальнейшее образование.", [
    choiceBtn("Готовиться каждый день", choiceEffects({add:{mind:30,discipline:18,school:30}, stats:{energy:-18,happiness:-8}, text:"Экзамены почти не страшны после такой подготовки."})),
    choiceBtn("Курсы подготовки", ()=>{ if(spend(60000) || game.familySupport>65){ add("mind",45); add("school",35); stat("energy",-8); passMonths(1,"Курсы дали мощный рывок."); } else passMonths(1,"Курсы оказались слишком дорогими."); }),
    choiceBtn("Надеяться на удачу", choiceEffects({add:{school:rand(0,20),luck:1}, stats:{happiness:4}, text:"Ты решил рискнуть."})),
  ])
];}
function youngEvents(){ return [studyEvent, workEvent, loveEvent, financeEvent, propertyEvent,
  ()=>makeEvent("Поворот молодости", "У тебя появился шанс резко изменить направление жизни.", [
    choiceBtn("Переехать в другой город", ()=>{ if(spend(120000)){ game.city="новый город"; add("charisma",10); add("fame",5); stat("happiness",10); passMonths(2,"Переезд открыл новые возможности."); } else passMonths(1,"На переезд не хватило денег."); }),
    choiceBtn("Запустить блог", choiceEffects({add:{charisma:22,creativity:20,fame:rand(20,80)}, stats:{energy:-12}, text:"Ты начал развивать личный блог."})),
    choiceBtn("Инвестировать в себя", ()=>{ if(spend(80000)){ add("mind",45); add("discipline",18); add("charisma",10); passMonths(1,"Инвестиция в себя окупится в будущем."); } else passMonths(1,"Денег на развитие не хватило."); }),
  ])
];}
function adultEvents(){ return [workEvent, loveEvent, propertyEvent, financeEvent, healthEvent, businessEvent,
  ()=>makeEvent("Большое жизненное решение", "Взрослая жизнь требует выбрать приоритеты.", [
    choiceBtn("Карьера", choiceEffects({add:{discipline:25,mind:15,fame:8,jobExp:20}, stats:{energy:-18,mental:-5}, text:"Ты сделал ставку на карьеру."})),
    choiceBtn("Семья", choiceEffects({stats:{happiness:18,mental:8}, add:{charisma:10}, text:"Ты уделил время семье и близким."})),
    choiceBtn("Деньги", choiceEffects({add:{business:1,discipline:10}, stats:{energy:-15,mental:-8}, text:"Ты сфокусировался на доходе и активах."})),
    choiceBtn("Здоровье", choiceEffects({stats:{health:22,energy:15,mental:12}, add:{discipline:8}, text:"Здоровье стало главным приоритетом."})),
  ]),
  ()=>makeEvent("Кризис среднего возраста", "Ты задумываешься, туда ли идёт жизнь.", [
    choiceBtn("Сменить профессию", ()=>{ game.job=null; stat("happiness",5); add("mind",15); passMonths(2,"Ты начал карьеру заново. Рискованно, но честно."); }),
    choiceBtn("Семейный отпуск", ()=>{ if(spend(180000)){ stat("happiness",25); stat("mental",20); passMonths(1,"Отпуск вернул вкус к жизни."); } else passMonths(1,"Отпуск оказался слишком дорогим."); }),
    choiceBtn("Терпеть дальше", choiceEffects({stats:{mental:-15,happiness:-8}, add:{discipline:8}, text:"Ты решил просто продолжать."})),
  ])
];}
function oldEvents(){ return [healthEvent, relationshipEvents()[0], parentEvents()[0], financeEvent,
  ()=>makeEvent("Мудрость возраста", "С годами меняются ценности. Что важнее теперь?", [
    choiceBtn("Семья и внуки", choiceEffects({stats:{happiness:22,mental:15}, add:{reputation:8}, text:"Близкие стали главным источником счастья."})),
    choiceBtn("Мемуары", choiceEffects({add:{fame:30,creativity:20,mind:10}, stats:{energy:-8}, text:"Ты начал записывать историю своей жизни."})),
    choiceBtn("Благотворительность", ()=>{ const sum=Math.min(game.money, rand(50000,500000)); game.money-=sum; add("reputation",30); add("fame",15); stat("happiness",18); passMonths(1,"Благотворительность оставила добрый след."); }),
    choiceBtn("Искать бессмертие", ()=>buyImmortality()),
  ]),
  ()=>makeEvent("Наследие", "Тебе предлагают оформить наследство и распределить имущество.", [
    choiceBtn("Семье", choiceEffects({stats:{happiness:14,mental:12}, add:{reputation:10}, text:"Семья почувствовала твою заботу."})),
    choiceBtn("Фонду", choiceEffects({add:{fame:35,reputation:30}, stats:{happiness:8}, text:"Ты решил оставить след в обществе."})),
    choiceBtn("Ничего не решать", choiceEffects({stats:{mental:-6}, text:"Ты отложил важный вопрос."})),
  ])
];}
function universalEvents(){ return [
  ()=>makeEvent("Обычный месяц", "Жизнь не всегда состоит из драм. Иногда важна стабильность.", [
    choiceBtn("Отдохнуть", choiceEffects({stats:{energy:22,happiness:8,mental:8}, text:"Спокойный отдых восстановил силы."})),
    choiceBtn("Учиться понемногу", choiceEffects({add:{mind:8,discipline:3}, stats:{energy:-5}, text:"Маленький шаг в развитии."})),
    choiceBtn("Общаться", choiceEffects({add:{charisma:8,friends:1}, stats:{happiness:7}, text:"Общение наполнило месяц."})),
  ]),
  ()=>makeEvent("Неожиданная возможность", "Кто-то предлагает авантюру с возможной выгодой.", [
    choiceBtn("Рискнуть", ()=>{ if(chance(45+game.luck*3)){ const win=rand(30000,250000); game.money+=win; add("fame",5); passMonths(1,"Риск окупился: +"+money(win)); } else { const loss=rand(10000,120000); game.money-=loss; stat("mental",-10); passMonths(1,"Риск не оправдался: -"+money(loss)); } }),
    choiceBtn("Отказаться", choiceEffects({add:{discipline:6}, stats:{mental:5}, text:"Ты выбрал спокойствие."})),
    choiceBtn("Изучить детали", choiceEffects({add:{mind:12,discipline:4}, stats:{energy:-5}, text:"Анализ помог понять риски."})),
  ])
];}
function hardEvents(){ return [
  ()=>makeEvent("Сложный период", "Навалились усталость, сомнения и проблемы.", [
    choiceBtn("Попросить помощи", choiceEffects({stats:{mental:18,happiness:8}, add:{charisma:4}, text:"Поддержка помогла пережить сложный период."})),
    choiceBtn("Решать самому", choiceEffects({stats:{mental:-6,energy:-10}, add:{discipline:18}, text:"Ты справился сам, но потратил много сил."})),
    choiceBtn("Сорваться", choiceEffects({stats:{health:-8,mental:-18,happiness:-10}, add:{addictions:5}, text:"Срыв ухудшил состояние."})),
  ]),
  ()=>makeEvent("Опасная ситуация", "Произошёл неприятный инцидент, который может навредить здоровью.", [
    choiceBtn("Действовать осторожно", choiceEffects({add:{discipline:8}, stats:{health:-3}, text:"Ты избежал серьёзных последствий."})),
    choiceBtn("Рискнуть", ()=>{ if(chance(35+game.luck*4)){ add("fame",10); passMonths(1,"Риск сделал тебя смелее и заметнее."); } else { stat("health",-25); passMonths(1,"Риск закончился травмой."); } }),
  ])
];}
function jobEvents(){ return [
  ()=>makeEvent("Ситуация на работе", "На работе возникла возможность проявить себя.", [
    choiceBtn("Взять сложную задачу", choiceEffects({add:{jobExp:18,mind:10,discipline:8,fame:3}, stats:{energy:-18,mental:-6}, text:"Сложная задача усилила карьеру."})),
    choiceBtn("Работать спокойно", choiceEffects({add:{jobExp:6}, stats:{energy:-6}, text:"Стабильная работа без риска."})),
    choiceBtn("Попросить повышение", ()=>promotion()),
    choiceBtn("Уволиться", ()=>{ game.job=null; stat("happiness",4); passMonths(1,"Ты уволился и освободил время."); }),
  ]),
  ()=>makeEvent("Конфликт с начальством", "Начальник несправедливо критикует твою работу.", [
    choiceBtn("Спокойно доказать правоту", choiceEffects({add:{charisma:10,discipline:8,jobExp:8}, stats:{mental:-3}, text:"Аргументы сработали."})),
    choiceBtn("Промолчать", choiceEffects({stats:{mental:-8,happiness:-5}, add:{discipline:4}, text:"Ты избежал конфликта, но стало неприятно."})),
    choiceBtn("Жёстко ответить", ()=>{ if(chance(35+game.charisma/10)){ add("reputation",10); passMonths(1,"Тебя начали уважать больше."); } else { game.job=null; passMonths(1,"Конфликт закончился увольнением."); } }),
  ])
];}
function relationshipEvents(){ return [
  ()=>makeEvent("Отношения", game.partner ? `В отношениях с ${game.partner} накопились важные вопросы.` : "В отношениях пришло время сделать следующий шаг.", [
    choiceBtn("Провести время вместе", choiceEffects({stats:{happiness:16,mental:8}, add:{love:12}, text:"Близость укрепила отношения."})),
    choiceBtn("Поговорить честно", choiceEffects({add:{charisma:8,love:18}, stats:{mental:5}, text:"Честный разговор помог понять друг друга."})),
    choiceBtn("Уйти в работу", choiceEffects({add:{discipline:8,jobExp:10}, stats:{happiness:-8}, text:"Работа отдалила тебя от близкого человека."})),
    choiceBtn("Расстаться", ()=>{ game.relationship="Одинок"; game.partner=null; game.love=0; stat("happiness",-20); passMonths(1,"Отношения закончились."); }),
  ])
];}
function parentEvents(){ return [
  ()=>makeEvent("Семейный вопрос", "Детям нужно внимание и ресурсы.", [
    choiceBtn("Провести день с детьми", choiceEffects({stats:{happiness:18,mental:10}, add:{reputation:4}, text:"Дети запомнят это время."})),
    choiceBtn("Вложиться в образование", ()=>{ const cost=game.children.length*50000; if(spend(cost)){ add("reputation",8); stat("happiness",8); passMonths(1,"Образование детей стало лучше."); } else passMonths(1,"На образование детей не хватило денег."); }),
    choiceBtn("Больше работать ради семьи", choiceEffects({add:{jobExp:15,discipline:10}, stats:{energy:-20,mental:-5}, text:"Ты заработал опыт, но устал."})),
  ])
];}
function businessEvents(){ return [
  ()=>makeEvent("Бизнес-решение", "Компания стоит перед выбором направления.", [
    choiceBtn("Расширяться", ()=>{ const cost=game.business*250000; if(spend(cost)){ game.business++; add("fame",20); passMonths(2,"Бизнес вырос до уровня " + game.business + "."); } else passMonths(1,"На расширение бизнеса не хватило средств."); }),
    choiceBtn("Оптимизировать", choiceEffects({add:{discipline:15,mind:10}, stats:{mental:-4}, money:game.business*rand(30000,90000), text:"Оптимизация улучшила прибыль."})),
    choiceBtn("Рискованный проект", ()=>{ if(chance(35+game.mind/30+game.luck)){ const gain=game.business*rand(120000,500000); game.money+=gain; add("fame",40); passMonths(2,"Рискованный проект выстрелил: +"+money(gain)); } else { const loss=game.business*rand(80000,300000); game.money-=loss; stat("mental",-14); passMonths(2,"Проект провалился: -"+money(loss)); } }),
  ])
];}

function broadLifeEvent(){ return pick(universalEvents())(); }
function studyEvent(){
  const a=ageYears();
  if(a<7) return pick(childEvents())();
  if(a<18) return pick(schoolEvents())();
  return makeEvent("Образование", "Ты можешь выбрать, куда направить развитие.", [
    choiceBtn("Университет", ()=>{ if(game.education==="Высшее") return passMonths(1,"Высшее образование уже есть."); if(spend(90000) || game.familySupport>70){ game.university+=30; add("mind",45); add("discipline",10); if(game.university>=100) game.education="Высшее"; passMonths(3,"Учёба в университете продвинулась."); } else passMonths(1,"На университет не хватило денег."); }),
    choiceBtn("Медицина", ()=>{ if(spend(120000)){ game.med+=28; add("mind",55); add("discipline",18); if(game.med>=100) game.education="Медицинское"; passMonths(4,"Медицинское обучение продвинулось."); } else passMonths(1,"Медицинское обучение слишком дорогое."); }),
    choiceBtn("Юриспруденция", ()=>{ if(spend(100000)){ game.law+=30; add("mind",35); add("charisma",20); if(game.law>=100) game.education="Юридическое"; passMonths(4,"Юридическое обучение продвинулось."); } else passMonths(1,"На юридическое обучение не хватило денег."); }),
    choiceBtn("Самообразование", choiceEffects({add:{mind:30,discipline:8,creativity:8}, stats:{energy:-12}, text:"Самообразование сделало тебя сильнее."})),
  ]);
}
function workEvent(){
  if(ageYears()<14) return makeEvent("Работа", "Ты ещё слишком мал для работы.", [choiceBtn("Вернуться", ()=>passMonths(1,"Месяц прошёл без работы."))]);
  const available = jobs.filter(j => ageYears()>=j.minAge && jobOK(j)).slice(0,5);
  const choices = available.map(j => choiceBtn("Стать: " + j.name, ()=>{ game.job={id:j.id,name:j.name}; game.jobLevel=1; add("fame", j.fame); passMonths(1,"Ты начал работать: " + j.name + "."); }));
  choices.push(choiceBtn("Фриланс", ()=>{ game.freelance++; add("mind",10); add("creativity",10); stat("energy",-10); passMonths(1,"Ты развил фриланс до уровня " + game.freelance + "."); }));
  if(game.job) choices.unshift(choiceBtn("Работать усердно", ()=>{ const earned = Math.round((game.jobLevel*50000 + game.mind*70 + rand(20000,80000))*game.countryMult); game.money += earned; add("jobExp",15); stat("energy",-25); stat("mental",-8); passMonths(1,"Усердная работа принесла " + money(earned) + "."); }));
  return makeEvent("Карьера", game.job ? `Текущая работа: ${game.job.name}. Можно развиваться или сменить путь.` : "Пора выбрать способ заработка.", choices.slice(0,6));
}
function jobOK(j){
  const r=j.req||{};
  if(r.education && game.education!==r.education) return false;
  for(const k of ["mind","charisma","creativity","discipline","fame"]){ if(r[k] && game[k]<r[k]) return false; }
  return true;
}
function promotion(){ if(!game.job) return passMonths(1,"Сначала нужна работа."); const p=25+game.jobExp/4+game.discipline/12+game.charisma/20; if(chance(p)){ game.jobLevel++; game.jobExp=0; add("fame",10); stat("happiness",10); passMonths(1,"Повышение! Уровень карьеры: "+game.jobLevel+"."); } else { stat("happiness",-5); passMonths(1,"Повышение пока не дали."); } }
function loveEvent(){
  if(ageYears()<14) return makeEvent("Отношения", "Серьёзные отношения будут позже, а пока важны друзья.", [choiceBtn("Завести друзей", choiceEffects({add:{friends:1,charisma:8}, stats:{happiness:10}, text:"Круг общения вырос."}))]);
  if(game.relationship==="Одинок") return makeEvent("Знакомство", "Появилась возможность познакомиться с интересным человеком.", [
    choiceBtn("Познакомиться", ()=>{ const p=35+game.charisma/8+game.looks/5+game.fame/20; if(chance(p)){ game.relationship="В отношениях"; game.partner=pick(["Алекс","Саша","Марина","Оля","Ира","Никита","Максим","Катя","Лена","Дима"]); game.love=rand(35,70); stat("happiness",18); passMonths(1,"Начались отношения с " + game.partner + "."); } else passMonths(1,"Знакомство не получилось."); }),
    choiceBtn("Искать друзей", choiceEffects({add:{friends:1,charisma:12}, stats:{happiness:8}, text:"Ты расширил круг общения."})),
    choiceBtn("Сосредоточиться на себе", choiceEffects({add:{mind:12,discipline:8}, stats:{happiness:-2}, text:"Ты выбрал развитие вместо отношений."})),
  ]);
  return makeEvent("Отношения", `Ты в отношениях с ${game.partner}. Любовь: ${game.love}/100.`, [
    choiceBtn("Свидание", ()=>{ if(spend(12000)){ add("love",18); stat("happiness",16); passMonths(1,"Свидание укрепило отношения."); } else passMonths(1,"На свидание не хватило денег."); }),
    choiceBtn("Съехаться", ()=>{ if(ageYears()<18) return passMonths(1,"Пока рано жить вместе."); game.relationship="Живём вместе"; add("love",12); stat("happiness",10); passMonths(1,"Вы начали жить вместе."); }),
    choiceBtn("Брак", ()=>{ if(game.love<70) return passMonths(1,"Для брака отношения ещё слабые."); if(spend(180000)){ game.relationship="Брак"; add("fame",10); stat("happiness",24); passMonths(1,"Свадьба состоялась."); } else passMonths(1,"На свадьбу не хватило денег."); }),
    choiceBtn("Ребёнок", ()=>{ if(game.relationship!=="Брак" && game.relationship!=="Живём вместе") return passMonths(1,"Для ребёнка нужна стабильная семья."); if(game.money<50000) return passMonths(1,"Ребёнок требует финансовой стабильности."); game.children.push({name:pick(["Миша","София","Даня","Алиса","Кира","Лев"]), born:game.month}); stat("happiness",20); add("reputation",8); passMonths(2,"В семье появился ребёнок."); }),
    choiceBtn("Расстаться", ()=>{ game.relationship="Одинок"; game.partner=null; game.love=0; stat("happiness",-22); passMonths(1,"Отношения закончились."); }),
  ]);
}
function propertyEvent(){
  if(ageYears()<18) return makeEvent("Имущество", "Покупка жилья и транспорта доступна во взрослой жизни.", [choiceBtn("Подождать", ()=>passMonths(1,"Пока ты живёшь с семьёй."))]);
  return makeEvent("Имущество", `Жильё: ${game.home}. Транспорт: ${game.transport}.`, [
    choiceBtn("Снять комнату", ()=>buyHome("Комната в аренду",1,70000)),
    choiceBtn("Купить квартиру", ()=>buyHome("Квартира",2,1200000)),
    choiceBtn("Купить дом", ()=>buyHome("Дом",3,4500000)),
    choiceBtn("Купить авто", ()=>buyCar("Автомобиль",1,450000)),
    choiceBtn("Переехать в страну", ()=>{ const c=pick(countries); if(spend(600000)){ game.country=c.name; game.countryMult=c.mult; game.expectedLife=c.life; stat("happiness",12); add("charisma",15); passMonths(3,"Ты переехал в страну: "+c.name+"."); } else passMonths(1,"Переезд стоит 600 000 ₽."); }),
  ]);
}
function buyHome(name, lvl, price){ if(game.homeLevel>=lvl) return passMonths(1,"У тебя уже есть жильё не хуже."); if(!spend(price)) return passMonths(1,"Не хватает денег на жильё."); game.home=name; game.homeLevel=lvl; stat("happiness",lvl*10); add("reputation",lvl*5); passMonths(1,"Новое жильё: "+name+"."); }
function buyCar(name, lvl, price){ if(game.carLevel>=lvl) return passMonths(1,"Транспорт уже есть."); if(!spend(price)) return passMonths(1,"Не хватает денег на транспорт."); game.transport=name; game.carLevel=lvl; stat("happiness",8); add("reputation",5); passMonths(1,"Покупка транспорта: "+name+"."); }
function financeEvent(){ return makeEvent("Деньги и активы", "Можно управлять деньгами, рисковать или строить капитал.", [
  choiceBtn("Купить акции", ()=>{ if(spend(100000)){ game.shares += 100000; passMonths(1,"Ты купил акции на 100 000 ₽."); } else passMonths(1,"На акции не хватило денег."); }),
  choiceBtn("Купить криптовалюту", ()=>{ if(spend(100000)){ game.crypto += 100000; passMonths(1,"Ты купил криптовалюту на 100 000 ₽."); } else passMonths(1,"На крипту не хватило денег."); }),
  choiceBtn("Взять кредит", ()=>{ game.money += 300000; game.debt += 420000; stat("mental",-5); passMonths(1,"Ты взял кредит 300 000 ₽. Вернуть придётся больше."); }),
  choiceBtn("Открыть бизнес", ()=>businessEvent()),
  choiceBtn("Купить бессмертие", ()=>buyImmortality()),
]); }
function businessEvent(){ return makeEvent("Бизнес", game.business ? `Твой бизнес уровня ${game.business}. Нужно принимать решения.` : "Можно начать своё дело, но это риск.", [
  choiceBtn("Открыть/расширить бизнес", ()=>{ const cost=(game.business+1)*350000; if(!spend(cost)) return passMonths(1,"Для бизнеса нужно " + money(cost) + "."); game.business++; game.businessName = game.businessName || pick(["студия приложений","кафе","магазин","агентство","онлайн-школа"]); add("fame",20); add("discipline",12); passMonths(2,"Бизнес вырос: "+game.businessName+", уровень "+game.business+"."); }),
  choiceBtn("Нанять команду", ()=>{ const cost=game.business*200000 || 200000; if(!spend(cost)) return passMonths(1,"На команду не хватило денег."); add("reputation",15); add("fame",15); stat("mental",8); passMonths(1,"Команда усилила бизнес."); }),
  choiceBtn("Рекламная кампания", ()=>{ const cost=150000; if(!spend(cost)) return passMonths(1,"Реклама стоит 150 000 ₽."); add("fame",rand(30,90)); passMonths(1,"Реклама привела новых клиентов."); }),
  choiceBtn("Продать бизнес", ()=>{ if(!game.business) return passMonths(1,"Продавать нечего."); const sale=game.business*rand(300000,900000); game.money+=sale; game.business=0; passMonths(1,"Бизнес продан за "+money(sale)+"."); }),
]); }
function healthEvent(){ return makeEvent("Здоровье", `Здоровье: ${game.health}/100. Психика: ${game.mental}/100. Болезнь: ${game.disease || "нет"}.`, [
  choiceBtn("Профилактика", ()=>{ if(spend(20000)){ stat("health",18); stat("mental",8); game.disease=null; passMonths(1,"Профилактика улучшила здоровье."); } else passMonths(1,"На профилактику не хватило денег."); }),
  choiceBtn("Спорт", choiceEffects({stats:{health:18,energy:-12,happiness:8}, add:{discipline:8}, text:"Спорт укрепил тело."})),
  choiceBtn("Психолог", ()=>{ if(spend(30000)){ stat("mental",30); stat("happiness",8); passMonths(1,"Психолог помог восстановиться."); } else passMonths(1,"Психолог стоит 30 000 ₽."); }),
  choiceBtn("Вредные привычки", choiceEffects({stats:{happiness:8,health:-14,mental:-8}, add:{addictions:8}, text:"Временное облегчение принесло вред."})),
  choiceBtn("Лечение премиум", ()=>{ if(spend(250000)){ game.health=100; game.mental=100; game.disease=null; passMonths(1,"Премиум лечение восстановило состояние."); } else passMonths(1,"Премиум лечение стоит 250 000 ₽."); }),
]); }
function otherEvent(){ return makeEvent("Другое", "Дополнительные возможности и информация о жизни.", [
  choiceBtn("Статистика", ()=>showStats()), choiceBtn("Дневник", ()=>showDiary()), choiceBtn("Достижения", ()=>showAchievements()), choiceBtn("Кладбище", ()=>showGraves()), choiceBtn("Настройки", ()=>showSettings()), choiceBtn("Главное меню", ()=>renderMenu())
]); }
function buyImmortality(){
  const ok = ageYears()>=45 && game.money>=10000000 && game.mind>=900 && game.fame>=500 && game.business>=4 && game.health>=60;
  if(!ok) return passMonths(1,"Таблетка бессмертия недоступна. Нужно: 45+ лет, 10 000 000 ₽, ум 900+, известность 500+, бизнес 4+, здоровье 60+.");
  game.money -= 10000000; game.immortal=true; game.immortalBought=true; game.health=100; game.mental=100; game.energy=100; add("fame",300); addAchievement("Бессмертный"); passMonths(1,"Ты купил таблетку бессмертия. Старость больше не властна над тобой.");
}

function renderMenu(){
  app.innerHTML=`<section class="screen menu-screen"><div class="particles">${Array.from({length:22},()=>`<i style="left:${rand(2,98)}%;bottom:${rand(-20,90)}%;animation-duration:${rand(5,12)}s;animation-delay:${rand(0,60)/10}s"></i>`).join("")}</div><div class="menu-wrap slide-up"><div class="title">НОВАЯ ЖИЗНЬ</div><div class="subtitle">пошаговый симулятор судьбы</div><div class="hero card floaty"><img src="img/hero.png"><div><h2>Story Edition</h2><p>Выборы, последствия, семья, карьера, болезни, богатство, смерть и разные финалы.</p></div></div><div class="menu-buttons"><button class="big-btn ${game?'btn-blue':'btn-gray'}" onclick="continueGame()">▶ Продолжить жизнь</button><button class="big-btn btn-green pulse" onclick="showNewGame()">+ Новая жизнь</button><button class="big-btn btn-orange" onclick="showGraves()">▣ Ваши игры</button><button class="big-btn btn-purple" onclick="showSettings()">⚙ Настройки</button><button class="big-btn btn-red" onclick="tryExit()">⏻ Выйти</button></div><div class="brand">LifeSim Studio • Story Edition v12</div></div></section>`;
  applyMusic();
}
function continueGame(){ vibrate(); if(!game) return toast("Сначала создай новую жизнь"); if(!currentEvent) currentEvent=generateEvent(); renderGame(); }
function renderGame(){
  if(!game) return renderMenu();
  if(!currentEvent) currentEvent = game.gameOver ? endingEvent() : generateEvent();
  const a=ageYears();
  const choices = currentEvent.choices || [];
  app.innerHTML=`<section class="screen game-screen"><div class="topbar"><button class="round-btn" onclick="renderMenu()">☰</button><div class="head-title"><h1>НОВАЯ ЖИЗНЬ</h1><span>${stage()} • ${monthName()} • ${a} лет</span></div><button class="round-btn shop-btn" onclick="forceEvent('money')">Активы</button></div><div class="pills"><div class="pill">${a} лет</div><div class="pill money">${money(game.money)}</div><div class="pill energy">Энергия ${game.energy}</div><div class="pill xp">Слава ${game.fame}</div></div><div class="scroll"><section class="profile card slide-up"><div class="profile-top"><img class="avatar floaty" src="img/${game.gender==='Женский'?'avatar_girl.png':'avatar_boy.png'}"><div><div class="name">${game.name}</div><div class="info">${game.country} | ${game.city}</div><div class="info">Семья: ${game.familyStatus}</div><div class="info">Работа: ${game.job?game.job.name:'нет'} | Отношения: ${game.relationship}</div></div></div><div class="bars">${barHTML("Здоровье",game.health,"#19a84d")}${barHTML("Счастье",game.happiness,"#f59e0b")}${barHTML("Энергия",game.energy,"#2f7df4")}${barHTML("Психика",game.mental,"#9b5cf6")}</div><div class="mini-stats">${miniHTML("Ум",game.mind,"#e9f5ff")}${miniHTML("Харизма",game.charisma,"#fff0f7")}${miniHTML("Творч.",game.creativity,"#fff6dc")}${miniHTML("Дисцип.",game.discipline,"#f0edff")}${miniHTML("Образ.",game.education,"#f0edff")}${miniHTML("Друзья",game.friends,"#eaf8ef")}${miniHTML("Бизнес",game.business,"#e7f8fb")}${miniHTML("Дети",game.children.length,"#fff0f5")}</div></section><section class="story-card card slide-up"><div class="story-kicker">Событие жизни</div><h2>${currentEvent.title}</h2><p>${currentEvent.text}</p></section><section class="choice-panel card slide-up"><h3>Что выбрать?</h3><div class="choice-list">${choices.map((c,i)=>`<button class="choice-btn" onclick="selectChoice(${i})"><b>${c.text}</b>${c.hint?`<span>${c.hint}</span>`:""}</button>`).join("")}</div></section><section class="quick-grid">${quickBtn("life","Жизнь","Жизненные события")}${quickBtn("study","Учёба","образование")}${quickBtn("work","Работа","карьера")}${quickBtn("love","Отношения","семья")}${quickBtn("property","Имущество","дом и авто")}${quickBtn("health","Здоровье","лечение")}</section></div><nav class="bottom-nav"><button class="nav-btn active" onclick="forceEvent('life')">Жизнь</button><button class="nav-btn" onclick="showDiary()">Дневник</button><button class="nav-btn" onclick="showStats()">Статы</button><button class="nav-btn" onclick="showGoals()">Цели</button></nav></section>`;
  applyMusic(); saveGame();
}
function barHTML(n,v,c){v=clamp(v); return `<div><div class="bar-label"><span>${n}</span><span>${v}/100</span></div><div class="track"><div class="fill" style="width:${v}%;background:${c}"></div></div></div>`;}
function miniHTML(t,v,b){return `<div class="mini" style="background:${b}"><span>${t}</span><b>${v}</b></div>`;}
function quickBtn(type,title,sub){ const map={life:"c-life",study:"c-study",work:"c-work",love:"c-love",property:"c-property",health:"c-health"}; const icon={life:"life",study:"study",work:"work",love:"love",property:"property",health:"health"}; return `<button class="tile ${map[type]}" onclick="forceEvent('${type}')"><img src="img/icon_${icon[type]}.png"><div><strong>${title}</strong><span>${sub}</span></div></button>`; }
function selectChoice(i){ vibrate(); const c=currentEvent.choices[i]; if(c && c.apply){ const res = c.apply(); if(res===false) return; } }
function forceEvent(type){ currentEvent=generateEvent(type); renderGame(); }

function showModal(t,txt,btns=[{text:"Закрыть",cls:"btn-blue",fn:closeModal}]){modalCard.innerHTML=`<h2>${t}</h2><div class="modal-line"></div><div class="modal-text">${txt}</div><div class="modal-actions">${btns.map((b,i)=>`<button class="big-btn ${b.cls||'btn-blue'}" onclick="modalButton(${i})">${b.text}</button>`).join("")}</div>`;window._modalButtons=btns;modalRoot.classList.remove("hidden");}
function modalButton(i){let b=window._modalButtons[i]; if(b&&b.fn)b.fn();}
function closeModal(){modalRoot.classList.add("hidden");}
function showNewGame(){modalCard.innerHTML=`<h2>Создать новую жизнь</h2><div class="modal-line"></div><input class="input" id="nameInput" placeholder="Имя персонажа" value="Zeus"/><div class="modal-actions"><button class="big-btn btn-blue" onclick="startGender('Мужской')">Мужской</button><button class="big-btn btn-red" onclick="startGender('Женский')">Женский</button><button class="big-btn btn-purple" onclick="startGender('Случайно')">Случайно</button><button class="big-btn btn-gray" onclick="closeModal()">Отмена</button></div>`;modalRoot.classList.remove("hidden");}
function startGender(g){ const n=$("#nameInput").value.trim(); closeModal(); newGame(n, g==="Случайно"?pick(["Мужской","Женский"]):g); }
function showDiary(){ if(!game) return; showModal("Дневник жизни", game.diary.length ? game.diary.map(x=>`${x.age} лет, ${x.month}: ${x.text}`).join("\n\n") : "Дневник пуст."); }
function showGoals(){ showModal("Цели", "Главная цель: прожить уникальную жизнь и открыть разные финалы.\n\nОсобая цель: таблетка бессмертия.\nНужно: 45+ лет, 10 000 000 ₽, ум 900+, известность 500+, бизнес 4+, здоровье 60+.\n\nВозможные финалы: магнат, знаменитость, глава семьи, гений, криминальная судьба, счастливая жизнь, бессмертная легенда и другие."); }
function showStats(){ if(!game)return; showModal("Статистика", `Имя: ${game.name}\nВозраст: ${ageYears()}\nСтрана: ${game.country}\nДеньги: ${money(game.money)}\nДолг: ${money(game.debt)}\nРабота: ${game.job?game.job.name:'нет'}\nКарьера: ${game.jobLevel}\nОбразование: ${game.education}\nБизнес: ${game.business}\nОтношения: ${game.relationship}${game.partner?' с '+game.partner:''}\nДети: ${game.children.length}\nДрузья: ${game.friends}\nДом: ${game.home}\nТранспорт: ${game.transport}\nАкции: ${money(game.shares)}\nКрипта: ${money(game.crypto)}\nДостижения: ${game.achievements.length}\nФинал: ${game.ending || 'ещё не наступил'}`); }
function showAchievements(){ showModal("Достижения", game?.achievements?.length ? game.achievements.join("\n") : "Пока достижений нет."); }
function showGraves(){ const list=loadJSON(GRAVES,[]); const html=list.length?list.map((g,i)=>`<button class="row-card" onclick="graveInfo(${i})">🪦 ${g.name}, ${g.age} лет — ${g.ending}</button>`).join(""):`<div class="row-card">Кладбище пустое. Проживи первую жизнь.</div>`; modalCard.innerHTML=`<h2>Ваши игры</h2><div class="modal-line"></div><div class="graves">${html}</div><div class="modal-actions"><button class="big-btn btn-blue" onclick="closeModal()">Закрыть</button></div>`; modalRoot.classList.remove("hidden"); }
function graveInfo(i){ const g=loadJSON(GRAVES,[])[i]; showModal("Прошлая жизнь", `Имя: ${g.name}\nВозраст: ${g.age}\nСтрана: ${g.country}\nФинал: ${g.ending}\nПричина: ${g.reason}\nДеньги: ${money(g.money)}\nСлава: ${g.fame}\nДети: ${g.children}\n\nПоследние записи:\n${(g.diary||[]).map(x=>x.text).join("\n")}`); }
function showSettings(){ const row=(k,t,s)=>`<div class="row-card setting-row" onclick="toggleSetting('${k}')"><div><b>${t}</b><span>${s}</span></div><div class="switch ${settings[k]?'on':''}"></div></div>`; modalCard.innerHTML=`<h2>Настройки</h2><div class="modal-line"></div><div class="settings">${row("music","Фоновая музыка","Музыка в меню и игре")}${row("sound","Звук","Эффекты действий")}${row("vibration","Вибрация","Отклик при нажатиях")}${row("autosave","Автосохранение","Сохранять после решений")}${row("cloud","Синхронизация","Заготовка под облако")}${row("google","Google Play Игры","Заготовка под достижения")}</div><div class="modal-actions"><button class="big-btn btn-blue" onclick="closeModal()">Закрыть</button></div>`; modalRoot.classList.remove("hidden"); }
function toggleSetting(k){ settings[k]=!settings[k]; saveJSON(SETTINGS,settings); applyMusic(); showSettings(); }
function tryExit(){ showModal("Выход", "Закрой приложение кнопкой телефона или сверни его."); }
window.NativeBack=function(){ if(!modalRoot.classList.contains("hidden")) closeModal(); else renderMenu(); };
renderMenu();
